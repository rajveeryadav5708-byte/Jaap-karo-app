/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { Play, Pause } from 'lucide-react';
import { NavTab, AppLanguage, ChantingState, AppSettings } from './types';
import {
  loadChantingState,
  saveChantingState,
  loadAppSettings,
  saveAppSettings,
  loadFavorites,
  saveFavorites,
  getTodayDateString,
  getYesterdayDateString
} from './utils/storage';
import { translations } from './data/translations';
import { getTodayThought } from './data/thoughts';
import { getMantraDisplay } from './data/mantras';
import { soundEngine } from './utils/audio';

// Components
import { FirstLaunchModal } from './components/FirstLaunchModal';
import { Header } from './components/Header';
import { TodayThoughtCard } from './components/TodayThoughtCard';
import { StatCards } from './components/StatCards';
import { MantraSelectorSheet } from './components/MantraSelectorSheet';
import { MalaCounter } from './components/MalaCounter';
import { ResetDialog, ResetType } from './components/ResetDialog';
import { BottomNav } from './components/BottomNav';
import { StreakView } from './components/StreakView';
import { StatsView } from './components/StatsView';
import { StoriesView } from './components/StoriesView';
import { VoiceView } from './components/VoiceView';
import { DevotionalGameView } from './components/DevotionalGameView';
import { SettingsView } from './components/SettingsView';

export default function App() {
  // App persistent settings
  const [appSettings, setAppSettings] = useState<AppSettings>(() => loadAppSettings());
  const [chantingState, setChantingState] = useState<ChantingState>(() => loadChantingState());
  const [favorites, setFavorites] = useState<string[]>(() => loadFavorites());

  // Active navigation state
  const [activeTab, setActiveTab] = useState<NavTab>(() => {
    return appSettings.rememberLastPage && appSettings.lastVisitedPage
      ? appSettings.lastVisitedPage
      : 'home';
  });
  const [isStreakPageOpen, setIsStreakPageOpen] = useState<boolean>(false);

  // Auto Chant state
  const [isAutoChantActive, setIsAutoChantActive] = useState<boolean>(false);
  const autoChantTimerRef = useRef<number | null>(null);

  // Mala completion celebration toast
  const [completionToast, setCompletionToast] = useState<string | null>(null);

  const t = translations[appSettings.language] || translations.hi;
  const todayThought = useMemoThought();

  // Save state on change
  useEffect(() => {
    saveChantingState(chantingState);
  }, [chantingState]);

  useEffect(() => {
    saveAppSettings(appSettings);
  }, [appSettings]);

  useEffect(() => {
    saveFavorites(favorites);
  }, [favorites]);

  // Keep lastVisitedPage updated if rememberLastPage is active
  useEffect(() => {
    if (appSettings.rememberLastPage && activeTab !== appSettings.lastVisitedPage) {
      setAppSettings((prev) => ({ ...prev, lastVisitedPage: activeTab }));
    }
  }, [activeTab, appSettings.rememberLastPage, appSettings.lastVisitedPage]);

  // Pause Auto Chant whenever leaving Home tab or app loses focus
  useEffect(() => {
    if (activeTab !== 'home' || isStreakPageOpen) {
      if (isAutoChantActive) {
        setIsAutoChantActive(false);
      }
    }
  }, [activeTab, isStreakPageOpen, isAutoChantActive]);

  useEffect(() => {
    const handleBlur = () => {
      setIsAutoChantActive(false);
      soundEngine.stopSpeech();
    };
    window.addEventListener('blur', handleBlur);
    return () => window.removeEventListener('blur', handleBlur);
  }, []);

  /**
   * Main Chant Tap Handler:
   * 1. Increases current bead counter
   * 2. Plays mantra voice (if voice enabled)
   * 3. Plays tactile sound and haptics
   * 4. Updates today's Jaap and lifetime total
   * 5. Checks for 108 Mala completion
   * 6. Updates daily streak automatically
   */
  const handleChant = useCallback(() => {
    const today = getTodayDateString();
    const yesterday = getYesterdayDateString();

    // Haptics & Audio
    soundEngine.triggerHaptic(18, appSettings.hapticsEnabled);
    soundEngine.playBell(1.0);

    if (chantingState.isVoiceEnabled) {
      const mantraInfo = getMantraDisplay(chantingState.selectedMantra);
      soundEngine.speakText(mantraInfo.devanagari, 'hi-IN', 1.1);
    }

    setChantingState((prev) => {
      const nextBeads = prev.currentBeads + 1;
      const nextTodayChants = prev.todayChants + 1;
      const nextLifetime = prev.lifetimeChants + 1;

      // Update streak if this is the first chant today
      let nextStreak = prev.currentStreak;
      let nextBestStreak = prev.bestStreak;

      const hasChantedTodayAlready = prev.dailyHistory[today] && prev.dailyHistory[today] > 0;
      if (!hasChantedTodayAlready && prev.todayChants === 0) {
        if (prev.lastChantedDate === yesterday) {
          nextStreak = prev.currentStreak + 1;
        } else if (prev.lastChantedDate !== today) {
          nextStreak = 1;
        }
        if (nextStreak > nextBestStreak) {
          nextBestStreak = nextStreak;
        }
      }

      // Updated history
      const updatedHistory = {
        ...prev.dailyHistory,
        [today]: (prev.dailyHistory[today] || 0) + 1
      };

      // Check if 108 Mala is completed
      const malaCapacity = prev.malaGoal ? 108 : 108;
      if (nextBeads >= malaCapacity) {
        // Celebratory Mala completion
        soundEngine.playMalaCompletedChime();
        soundEngine.triggerHaptic([100, 50, 150], appSettings.hapticsEnabled);

        // Confetti celebration
        try {
          confetti({
            particleCount: 75,
            spread: 60,
            origin: { y: 0.65 },
            colors: ['#F39812', '#FFD700', '#E65100', '#FFFFFF']
          });
        } catch {
          // Confetti fallback
        }

        setCompletionToast(t.malaCompletedToast);
        setTimeout(() => setCompletionToast(null), 3500);

        return {
          ...prev,
          currentBeads: 0, // resets for next mala
          todayChants: nextTodayChants,
          todayMalas: prev.todayMalas + 1,
          lifetimeChants: nextLifetime,
          currentStreak: nextStreak,
          bestStreak: nextBestStreak,
          lastChantedDate: today,
          dailyHistory: updatedHistory
        };
      }

      return {
        ...prev,
        currentBeads: nextBeads,
        todayChants: nextTodayChants,
        lifetimeChants: nextLifetime,
        currentStreak: nextStreak,
        bestStreak: nextBestStreak,
        lastChantedDate: today,
        dailyHistory: updatedHistory
      };
    });
  }, [
    appSettings.hapticsEnabled,
    chantingState.isVoiceEnabled,
    chantingState.selectedMantra,
    t.malaCompletedToast
  ]);

  // Auto Chant Timer implementation
  useEffect(() => {
    if (!isAutoChantActive) {
      if (autoChantTimerRef.current) {
        clearInterval(autoChantTimerRef.current);
        autoChantTimerRef.current = null;
      }
      return;
    }

    const intervalMs = Math.max(500, Math.round(appSettings.autoJaapSpeed * 1000));
    autoChantTimerRef.current = window.setInterval(() => {
      handleChant();
    }, intervalMs);

    return () => {
      if (autoChantTimerRef.current) {
        clearInterval(autoChantTimerRef.current);
        autoChantTimerRef.current = null;
      }
    };
  }, [isAutoChantActive, appSettings.autoJaapSpeed, handleChant]);

  // Reset Progress Handlers
  const handleConfirmReset = (type: ResetType) => {
    setChantingState((prev) => {
      if (type === 'beads') {
        return { ...prev, currentBeads: 0 };
      }
      if (type === 'today') {
        return { ...prev, currentBeads: 0, todayChants: 0 };
      }
      if (type === 'malas') {
        return { ...prev, todayMalas: 0 };
      }
      if (type === 'all') {
        return {
          currentBeads: 0,
          todayChants: 0,
          todayMalas: 0,
          lifetimeChants: 0,
          currentStreak: 0,
          bestStreak: 0,
          lastChantedDate: getTodayDateString(),
          dailyHistory: {},
          selectedMantra: 'RADHA',
          customMantras: [],
          isVoiceEnabled: false,
          autoChantSpeed: 1.5,
          malaGoal: 1
        };
      }
      return prev;
    });
  };

  const handleToggleFavoriteStory = (storyId: string) => {
    setFavorites((prev) =>
      prev.includes(storyId) ? prev.filter((id) => id !== storyId) : [...prev, storyId]
    );
  };

  // Render Streak view when opened
  if (isStreakPageOpen) {
    return (
      <StreakView
        currentStreak={chantingState.currentStreak}
        bestStreak={chantingState.bestStreak}
        dailyHistory={chantingState.dailyHistory}
        todayChants={chantingState.todayChants}
        currentLang={appSettings.language}
        onBack={() => setIsStreakPageOpen(false)}
      />
    );
  }

  return (
    <div className="w-full min-h-screen bg-[#FFFBF0] flex flex-col font-sans select-none antialiased">
      {/* First Launch Language Selector Modal */}
      {!appSettings.firstLaunchCompleted && (
        <FirstLaunchModal
          currentLang={appSettings.language}
          onSelectLanguage={(lang) => setAppSettings((prev) => ({ ...prev, language: lang }))}
          onContinue={() => setAppSettings((prev) => ({ ...prev, firstLaunchCompleted: true }))}
        />
      )}

      {/* Mala Completed Celebration Toast */}
      {completionToast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold text-xs shadow-xl animate-in fade-in slide-in-from-top duration-250 flex items-center gap-2">
          <span>{completionToast}</span>
        </div>
      )}

      {/* Main Tab Views */}
      {activeTab === 'home' && (
        <div className="w-full min-h-screen flex flex-col pb-24">
          {/* Header */}
          <Header
            currentLang={appSettings.language}
            streakCount={chantingState.currentStreak}
            onOpenStreak={() => setIsStreakPageOpen(true)}
          />

          {/* Home Content Container */}
          <div className="p-4 space-y-4 max-w-md mx-auto w-full flex-1 flex flex-col justify-between">
            {/* Today's Thought Card */}
            <TodayThoughtCard
              thought={todayThought}
              currentLang={appSettings.language}
            />

            {/* Jaap Statistics Cards: JAAP, MALA, TOTAL */}
            <StatCards
              todayChants={chantingState.todayChants}
              todayMalas={chantingState.todayMalas}
              malaGoal={appSettings.dailyGoalMalas}
              lifetimeChants={chantingState.lifetimeChants}
              currentLang={appSettings.language}
            />

            {/* Select God's Name / Mantra Card */}
            <MantraSelectorSheet
              selectedMantra={chantingState.selectedMantra}
              customMantras={chantingState.customMantras}
              currentLang={appSettings.language}
              onSelectMantra={(m) => setChantingState((prev) => ({ ...prev, selectedMantra: m }))}
              onAddCustomMantra={(m) =>
                setChantingState((prev) => ({
                  ...prev,
                  customMantras: [...new Set([...prev.customMantras, m])]
                }))
              }
            />

            {/* Main Jaap Counter: Circular 108-Bead Mala */}
            <MalaCounter
              currentBeads={chantingState.currentBeads}
              selectedMantra={chantingState.selectedMantra}
              isVoiceEnabled={chantingState.isVoiceEnabled}
              currentLang={appSettings.language}
              onChantTap={handleChant}
              onToggleVoice={() =>
                setChantingState((prev) => ({ ...prev, isVoiceEnabled: !prev.isVoiceEnabled }))
              }
            />

            {/* Action Buttons: AUTO CHANT & RESET PROGRESS */}
            <div className="flex items-center gap-2.5 pt-1">
              {/* Auto Chant Button */}
              <button
                onClick={() => setIsAutoChantActive((prev) => !prev)}
                className={`flex-1 h-12 rounded-2xl font-bold text-xs uppercase tracking-wider shadow-xs active:scale-[0.98] transition-all flex items-center justify-center gap-2 ${
                  isAutoChantActive
                    ? 'bg-amber-600 text-white shadow-amber-600/20 ring-2 ring-amber-400/30'
                    : 'bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white shadow-orange-500/20'
                }`}
              >
                {isAutoChantActive ? (
                  <>
                    <Pause className="w-4 h-4 fill-white" />
                    <span className="font-hindi">{t.pause} ({t.autoChant})</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-white" />
                    <span className="font-hindi">{t.autoChant}</span>
                  </>
                )}
              </button>

              {/* Reset / Jaap Progress Button */}
              <ResetDialog
                currentLang={appSettings.language}
                onConfirmReset={handleConfirmReset}
              />
            </div>
          </div>
        </div>
      )}

      {activeTab === 'stats' && (
        <StatsView
          currentLang={appSettings.language}
          dailyHistory={chantingState.dailyHistory}
          todayChants={chantingState.todayChants}
          todayMalas={chantingState.todayMalas}
          currentStreak={chantingState.currentStreak}
          bestStreak={chantingState.bestStreak}
          selectedMantra={chantingState.selectedMantra}
        />
      )}

      {activeTab === 'stories' && (
        <StoriesView
          currentLang={appSettings.language}
          favorites={favorites}
          onToggleFavorite={handleToggleFavoriteStory}
        />
      )}

      {activeTab === 'voice' && (
        <VoiceView currentLang={appSettings.language} />
      )}

      {activeTab === 'game' && (
        <DevotionalGameView
          currentLang={appSettings.language}
          hapticsEnabled={appSettings.hapticsEnabled}
        />
      )}

      {activeTab === 'settings' && (
        <SettingsView
          settings={appSettings}
          onUpdateSettings={(updated) =>
            setAppSettings((prev) => ({ ...prev, ...updated }))
          }
        />
      )}

      {/* Fixed Bottom Navigation (6 sections) */}
      <BottomNav
        activeTab={activeTab}
        currentLang={appSettings.language}
        onSelectTab={(tab) => {
          setIsAutoChantActive(false);
          setActiveTab(tab);
        }}
      />
    </div>
  );
}

function useMemoThought() {
  const [thought, setThought] = useState(() => getTodayThought());
  useEffect(() => {
    setThought(getTodayThought());
  }, []);
  return thought;
}
