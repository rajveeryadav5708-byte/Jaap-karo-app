/**
 * Type definitions for Jaap Karo
 */

export type AppLanguage = 'hi' | 'en' | 'sa' | 'gu' | 'mr' | 'bn' | 'te' | 'ta';

export type NavTab = 'home' | 'stats' | 'stories' | 'voice' | 'game' | 'settings';

export interface MantraItem {
  id: string;
  name: string;
  devanagari: string;
  english: string;
  deity: string;
  meaning: string;
  pronunciation: string;
}

export interface DailyThought {
  id: number;
  quote: {
    hi: string;
    en: string;
    sa?: string;
  };
  author: {
    hi: string;
    en: string;
  };
  source?: string;
}

export interface ChantingState {
  currentBeads: number; // 0 to 108
  todayChants: number;
  todayMalas: number;
  lifetimeChants: number;
  currentStreak: number;
  bestStreak: number;
  lastChantedDate: string; // YYYY-MM-DD
  dailyHistory: Record<string, number>; // "YYYY-MM-DD" -> count
  selectedMantra: string; // mantra name or id
  customMantras: string[];
  isVoiceEnabled: boolean;
  autoChantSpeed: number; // in seconds, default 1.5
  malaGoal: number; // daily goal in malas
}

export interface AppSettings {
  language: AppLanguage;
  dailyGoalMalas: number;
  autoJaapSpeed: number;
  hapticsEnabled: boolean;
  notificationsEnabled: boolean;
  reminderTime: string;
  rememberLastPage: boolean;
  lastVisitedPage: NavTab;
  firstLaunchCompleted: boolean;
}

export interface Story {
  id: string;
  title: {
    hi: string;
    en: string;
  };
  category: 'ramayana' | 'mahabharata' | 'krishna' | 'shiva' | 'vishnu' | 'hanuman' | 'devi' | 'bhakt' | 'puranas' | 'gita';
  deity: string;
  summary: {
    hi: string;
    en: string;
  };
  content: {
    hi: string[];
    en: string[];
  };
  moral: {
    hi: string;
    en: string;
  };
  readTimeMinutes: number;
}
