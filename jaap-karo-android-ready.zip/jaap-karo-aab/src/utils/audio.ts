/**
 * Audio and Haptics utility for Jaap Karo
 * Generates peaceful temple chime frequencies using Web Audio API
 * and handles devotional Speech Synthesis.
 */

class SacredSoundEngine {
  private ctx: AudioContext | null = null;
  private tanpuraOsc: OscillatorNode | null = null;
  private tanpuraGain: GainNode | null = null;
  private isDroneActive: boolean = false;

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  /**
   * Plays a peaceful, pure meditative temple singing bowl/bell harmonic tone
   */
  playBell(pitchMultiplier = 1) {
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const baseFreq = 432 * pitchMultiplier; // 432Hz sacred tuning

      // Fundamental harmonic
      const osc1 = this.ctx.createOscillator();
      const gain1 = this.ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(baseFreq, now);

      // Overtones
      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(baseFreq * 2.76, now); // Bell metallic overtone

      const osc3 = this.ctx.createOscillator();
      const gain3 = this.ctx.createGain();
      osc3.type = 'sine';
      osc3.frequency.setValueAtTime(baseFreq * 5.4, now); // Shimmer

      // Envelopes
      gain1.gain.setValueAtTime(0, now);
      gain1.gain.linearRampToValueAtTime(0.35, now + 0.015);
      gain1.gain.exponentialRampToValueAtTime(0.0001, now + 1.2);

      gain2.gain.setValueAtTime(0, now);
      gain2.gain.linearRampToValueAtTime(0.12, now + 0.01);
      gain2.gain.exponentialRampToValueAtTime(0.0001, now + 0.8);

      gain3.gain.setValueAtTime(0, now);
      gain3.gain.linearRampToValueAtTime(0.05, now + 0.008);
      gain3.gain.exponentialRampToValueAtTime(0.0001, now + 0.4);

      osc1.connect(gain1);
      osc2.connect(gain2);
      osc3.connect(gain3);

      gain1.connect(this.ctx.destination);
      gain2.connect(this.ctx.destination);
      gain3.connect(this.ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc3.start(now);

      osc1.stop(now + 1.25);
      osc2.stop(now + 0.85);
      osc3.stop(now + 0.45);
    } catch {
      // AudioContext unavailable
    }
  }

  /**
   * Plays a celebratory shankha / conch shell fanfare when a 108 Mala is completed
   */
  playMalaCompletedChime() {
    try {
      this.initCtx();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      // Sequence of notes in sacred raga
      const notes = [432, 540, 648, 864];
      notes.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.2);

        gain.gain.setValueAtTime(0, now + idx * 0.2);
        gain.gain.linearRampToValueAtTime(0.25, now + idx * 0.2 + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.2 + 0.9);

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now + idx * 0.2);
        osc.stop(now + idx * 0.2 + 0.95);
      });
    } catch {
      // AudioContext fallback
    }
  }

  /**
   * Plays balloon pop sound effect for the mini-game
   */
  playPop() {
    try {
      this.initCtx();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(150, now + 0.08);

      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.09);
    } catch {
      // AudioContext fallback
    }
  }

  /**
   * Pronounces mantra or word using Web Speech API with clean fallback
   */
  speakText(text: string, lang = 'hi-IN', rate = 1.0) {
    if (!('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = rate;
      utterance.pitch = 0.95; // Devotional calm pitch
      window.speechSynthesis.speak(utterance);
    } catch {
      // Speech synthesis error handled gracefully
    }
  }

  stopSpeech() {
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // Ignored
      }
    }
  }

  /**
   * Triggers haptic vibration if supported and enabled
   */
  triggerHaptic(pattern: number | number[] = 15, hapticsEnabled = true) {
    if (!hapticsEnabled) return;
    if (typeof window !== 'undefined' && 'navigator' in window && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch {
        // Not supported or blocked
      }
    }
  }
}

export const soundEngine = new SacredSoundEngine();
