import { AppSettings, ChantingState } from '../types';

const STORAGE_KEY_STATE = 'jaap_karo_state_v2';
const STORAGE_KEY_SETTINGS = 'jaap_karo_settings_v2';
const STORAGE_KEY_FAVORITES = 'jaap_karo_favorites_v2';
const STORAGE_KEY_HIGHSCORE = 'jaap_karo_highscore_v2';

export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getYesterdayDateString(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export const defaultSettings: AppSettings = {
  language: 'hi',
  dailyGoalMalas: 1,
  autoJaapSpeed: 1.5,
  hapticsEnabled: true,
  notificationsEnabled: true,
  reminderTime: '06:00',
  rememberLastPage: true,
  lastVisitedPage: 'home',
  firstLaunchCompleted: false
};

export const defaultChantingState: ChantingState = {
  currentBeads: 0,
  todayChants: 0,
  todayMalas: 0,
  lifetimeChants: 0,
  currentStreak: 0,
  bestStreak: 0,
  lastChantedDate: '',
  dailyHistory: {},
  selectedMantra: 'RADHA',
  customMantras: [],
  isVoiceEnabled: false,
  autoChantSpeed: 1.5,
  malaGoal: 1
};

export function loadChantingState(): ChantingState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_STATE);
    const today = getTodayDateString();
    const yesterday = getYesterdayDateString();

    if (!raw) {
      return { ...defaultChantingState, lastChantedDate: today };
    }

    const parsed: ChantingState = JSON.parse(raw);
    
    // Check if new day
    if (parsed.lastChantedDate && parsed.lastChantedDate !== today) {
      // Save yesterday's todayChants into history if not already recorded
      if (parsed.todayChants > 0 && !parsed.dailyHistory[parsed.lastChantedDate]) {
        parsed.dailyHistory[parsed.lastChantedDate] = parsed.todayChants;
      }

      // Check streak continuity:
      // If user chanted yesterday, streak stays alive.
      // If user missed yesterday, current streak resets to 0.
      if (parsed.lastChantedDate !== yesterday && parsed.lastChantedDate !== today) {
        parsed.currentStreak = 0;
      }

      parsed.todayChants = 0;
      parsed.todayMalas = 0;
      parsed.currentBeads = 0;
      parsed.lastChantedDate = today;
    }

    return {
      ...defaultChantingState,
      ...parsed,
      dailyHistory: parsed.dailyHistory || {},
      customMantras: parsed.customMantras || []
    };
  } catch {
    return defaultChantingState;
  }
}

export function saveChantingState(state: ChantingState) {
  try {
    localStorage.setItem(STORAGE_KEY_STATE, JSON.stringify(state));
  } catch {
    // LocalStorage write failed
  }
}

export function loadAppSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (!raw) return defaultSettings;
    return { ...defaultSettings, ...JSON.parse(raw) };
  } catch {
    return defaultSettings;
  }
}

export function saveAppSettings(settings: AppSettings) {
  try {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  } catch {
    // LocalStorage write failed
  }
}

export function loadFavorites(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_FAVORITES);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveFavorites(favs: string[]) {
  try {
    localStorage.setItem(STORAGE_KEY_FAVORITES, JSON.stringify(favs));
  } catch {
    // LocalStorage write failed
  }
}

export function loadGameHighScore(): number {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_HIGHSCORE);
    return raw ? parseInt(raw, 10) : 0;
  } catch {
    return 0;
  }
}

export function saveGameHighScore(score: number) {
  try {
    const current = loadGameHighScore();
    if (score > current) {
      localStorage.setItem(STORAGE_KEY_HIGHSCORE, String(score));
    }
  } catch {
    // LocalStorage write failed
  }
}
