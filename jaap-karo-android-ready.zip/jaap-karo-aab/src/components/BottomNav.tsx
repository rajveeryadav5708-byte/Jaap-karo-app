import React from 'react';
import { Home, BarChart2, BookOpen, Volume2, Gamepad2, Settings } from 'lucide-react';
import { NavTab, AppLanguage } from '../types';
import { translations } from '../data/translations';

interface BottomNavProps {
  activeTab: NavTab;
  currentLang: AppLanguage;
  onSelectTab: (tab: NavTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  currentLang,
  onSelectTab
}) => {
  const t = translations[currentLang] || translations.hi;

  const navItems: {
    id: NavTab;
    labelHi: string;
    labelEn: string;
    icon: React.ComponentType<{ className?: string }>;
  }[] = [
    { id: 'home', labelHi: 'होम', labelEn: 'Home', icon: Home },
    { id: 'stats', labelHi: 'आंकड़े', labelEn: 'Stats', icon: BarChart2 },
    { id: 'stories', labelHi: 'कथाएं', labelEn: 'Stories', icon: BookOpen },
    { id: 'voice', labelHi: 'ध्वनि', labelEn: 'Voice', icon: Volume2 },
    { id: 'game', labelHi: 'खेल', labelEn: 'Game', icon: Gamepad2 },
    { id: 'settings', labelHi: 'सेटिंग्स', labelEn: 'Settings', icon: Settings }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-amber-200/80 shadow-lg px-2 py-1.5 flex items-center justify-around max-w-lg mx-auto">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        const label = currentLang === 'en' ? item.labelEn : item.labelHi;

        return (
          <button
            key={item.id}
            onClick={() => onSelectTab(item.id)}
            className={`flex-1 py-1 flex flex-col items-center justify-center relative active:scale-95 transition-all ${
              isActive ? 'text-orange-500 font-bold' : 'text-stone-400 hover:text-stone-600'
            }`}
          >
            <div className="relative">
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
              {isActive && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-orange-500" />
              )}
            </div>

            <span className={`text-[10px] mt-1 font-hindi tracking-tight ${isActive ? 'text-orange-600 font-bold' : 'text-stone-400'}`}>
              {label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
