import React, { useState, useMemo } from 'react';
import confetti from 'canvas-confetti';
import { Volume2, VolumeX, SlidersHorizontal, Sparkles } from 'lucide-react';
import { AppLanguage } from '../types';
import { translations } from '../data/translations';
import { getMantraDisplay } from '../data/mantras';

interface MalaCounterProps {
  currentBeads: number;
  selectedMantra: string;
  isVoiceEnabled: boolean;
  currentLang: AppLanguage;
  malaCapacity?: number; // default 108
  onChantTap: () => void;
  onToggleVoice: () => void;
  onChangeMalaCapacity?: (capacity: number) => void;
}

interface FloatingMantra {
  id: number;
  text: string;
}

export const MalaCounter: React.FC<MalaCounterProps> = ({
  currentBeads,
  selectedMantra,
  isVoiceEnabled,
  currentLang,
  malaCapacity = 108,
  onChantTap,
  onToggleVoice,
  onChangeMalaCapacity
}) => {
  const [floatingMantras, setFloatingMantras] = useState<FloatingMantra[]>([]);
  const [showOptionsModal, setShowOptionsModal] = useState(false);
  const t = translations[currentLang] || translations.hi;
  const mantraInfo = getMantraDisplay(selectedMantra);

  // Compute 108 beads coordinates along circular circumference
  const beads = useMemo(() => {
    const list = [];
    const cx = 160;
    const cy = 160;
    const r = 138;
    const count = malaCapacity;

    for (let i = 0; i < count; i++) {
      // Start from top (-PI/2) and rotate clockwise
      const angle = -Math.PI / 2 + (2 * Math.PI * i) / count;
      const x = cx + r * Math.cos(angle);
      const y = cy + r * Math.sin(angle);
      list.push({ index: i, x, y });
    }
    return list;
  }, [malaCapacity]);

  const handleTap = () => {
    // Spawn floating mantra text animation
    const newId = Date.now() + Math.random();
    setFloatingMantras((prev) => [...prev.slice(-3), { id: newId, text: mantraInfo.devanagari }]);

    setTimeout(() => {
      setFloatingMantras((prev) => prev.filter((item) => item.id !== newId));
    }, 1200);

    onChantTap();
  };

  return (
    <div className="w-full flex flex-col items-center select-none py-1">
      {/* Top action controls: Mala options & Voice toggle */}
      <div className="w-full max-w-xs flex items-center justify-between px-2 mb-2">
        <button
          onClick={() => setShowOptionsModal(true)}
          className="w-10 h-10 rounded-full bg-white border border-amber-200 text-stone-700 hover:text-orange-600 hover:border-orange-300 flex items-center justify-center shadow-xs active:scale-95 transition-all"
          title="Mala Capacity Options"
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>

        <div className="text-center">
          <span className="text-xs font-bold text-orange-600 tracking-wider font-hindi uppercase">
            {mantraInfo.devanagari}
          </span>
        </div>

        <button
          onClick={onToggleVoice}
          className={`w-10 h-10 rounded-full border flex items-center justify-center shadow-xs active:scale-95 transition-all ${
            isVoiceEnabled
              ? 'bg-orange-500 text-white border-orange-600 ring-2 ring-orange-400/30'
              : 'bg-white text-stone-400 border-amber-200 hover:text-stone-700'
          }`}
          title={isVoiceEnabled ? 'Voice Enabled' : 'Voice Muted'}
        >
          {isVoiceEnabled ? (
            <Volume2 className="w-4 h-4" />
          ) : (
            <VolumeX className="w-4 h-4" />
          )}
        </button>
      </div>

      {/* Main 108-Bead Circular Mala Counter */}
      <div
        className="relative w-[320px] h-[320px] flex items-center justify-center cursor-pointer touch-manipulation active:scale-[0.99] transition-transform"
        onClick={handleTap}
      >
        {/* SVG Mala */}
        <svg
          viewBox="0 0 320 320"
          className="w-full h-full pointer-events-none drop-shadow-sm overflow-visible"
        >
          <defs>
            {/* Rudraksha completed bead gradient */}
            <radialGradient id="rudrakshaBead" cx="35%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#A0522D" />
              <stop offset="45%" stopColor="#7B3F00" />
              <stop offset="100%" stopColor="#4A2200" />
            </radialGradient>

            {/* Glowing Golden Current Bead Gradient */}
            <radialGradient id="goldenBead" cx="30%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#FFF9C4" />
              <stop offset="35%" stopColor="#FFD54F" />
              <stop offset="85%" stopColor="#F57C00" />
              <stop offset="100%" stopColor="#E65100" />
            </radialGradient>

            {/* Inactive bead gradient */}
            <radialGradient id="uncompletedBead" cx="35%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="60%" stopColor="#FBF7EE" />
              <stop offset="100%" stopColor="#E7DECD" />
            </radialGradient>

            {/* Golden Glow Filter */}
            <filter id="goldenGlow" x="-50%" y="-50%" width="200%" height="200%">
              <feDropShadow dx="0" dy="0" stdDeviation="3.5" floodColor="#F59E0B" floodOpacity="0.85" />
            </filter>
          </defs>

          {/* Background thread line holding beads */}
          <circle
            cx="160"
            cy="160"
            r="138"
            fill="none"
            stroke="#E6DAC4"
            strokeWidth="1.5"
            strokeDasharray="2 3"
          />

          {/* Sumeru / Guru Bead Tassel Indicator at the Top */}
          <g transform="translate(160, 16)">
            {/* Sacred tassel knot */}
            <polygon points="-4,-2 4,-2 2,6 -2,6" fill="#F39812" />
            <line x1="0" y1="6" x2="0" y2="12" stroke="#E67E00" strokeWidth="2" />
          </g>

          {/* The 108 Beads */}
          {beads.map((bead) => {
            const isCompleted = bead.index < currentBeads;
            const isCurrent = bead.index === currentBeads;

            if (isCurrent) {
              return (
                <g key={bead.index}>
                  {/* Outer pulse aura */}
                  <circle
                    cx={bead.x}
                    cy={bead.y}
                    r="8.5"
                    fill="none"
                    stroke="#F59E0B"
                    strokeWidth="1.5"
                    opacity="0.6"
                    className="animate-ping origin-center"
                    style={{ transformOrigin: `${bead.x}px ${bead.y}px` }}
                  />
                  {/* Active golden bead */}
                  <circle
                    cx={bead.x}
                    cy={bead.y}
                    r="6.5"
                    fill="url(#goldenBead)"
                    stroke="#D97706"
                    strokeWidth="1.2"
                    filter="url(#goldenGlow)"
                  />
                </g>
              );
            }

            if (isCompleted) {
              return (
                <circle
                  key={bead.index}
                  cx={bead.x}
                  cy={bead.y}
                  r="4.2"
                  fill="url(#rudrakshaBead)"
                  stroke="#381900"
                  strokeWidth="0.6"
                />
              );
            }

            // Uncompleted bead
            return (
              <circle
                key={bead.index}
                cx={bead.x}
                cy={bead.y}
                r="3.6"
                fill="url(#uncompletedBead)"
                stroke="#CFC4B0"
                strokeWidth="0.8"
              />
            );
          })}
        </svg>

        {/* Center Chanting Dial */}
        <div className="absolute inset-14 rounded-full bg-gradient-to-b from-white via-[#FFFDF8] to-[#FFF6E5] border border-amber-200/90 shadow-inner flex flex-col items-center justify-center p-4">
          {/* Subtle concentric decorative ring */}
          <div className="absolute inset-2 rounded-full border border-amber-100 pointer-events-none" />

          {/* Floating Mantra text animations */}
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center overflow-visible">
            {floatingMantras.map((m) => (
              <span
                key={m.id}
                className="absolute text-orange-600 font-bold text-lg font-devotional animate-mantra-float drop-shadow-sm"
              >
                {m.text}
              </span>
            ))}
          </div>

          {/* Current Bead Number Counter */}
          <div className="flex flex-col items-center justify-center z-10">
            <span className="text-5xl font-extrabold text-stone-900 tracking-tight tabular-nums font-sans">
              {currentBeads}
            </span>

            {/* Target 108 & Label */}
            <div className="flex items-center gap-1.5 mt-0.5 text-stone-400 text-xs font-semibold uppercase tracking-wider">
              <span>{malaCapacity}</span>
              <span>·</span>
              <span className="text-orange-600 font-bold">
                {t.chants}
              </span>
            </div>

            <div className="mt-2 text-[10px] text-stone-400 font-medium">
              {t.chantNow}
            </div>
          </div>
        </div>
      </div>

      {/* Mala Capacity Options Modal */}
      {showOptionsModal && onChangeMalaCapacity && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/50 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-white rounded-3xl p-5 shadow-2xl border border-amber-200 text-center">
            <h4 className="font-bold text-stone-900 text-base mb-1 font-hindi">
              माला मनका संख्या (Mala Beads)
            </h4>
            <p className="text-xs text-stone-500 mb-4">
              प्रति माला मंत्र जप संख्या चुनें
            </p>

            <div className="grid grid-cols-3 gap-2 mb-4">
              {[27, 54, 108].map((num) => (
                <button
                  key={num}
                  onClick={() => {
                    onChangeMalaCapacity(num);
                    setShowOptionsModal(false);
                  }}
                  className={`py-3 rounded-xl border font-bold text-sm transition-all ${
                    malaCapacity === num
                      ? 'border-orange-500 bg-orange-50 text-orange-900'
                      : 'border-stone-200 bg-stone-50 text-stone-700 hover:border-amber-300'
                  }`}
                >
                  {num}
                </button>
              ))}
            </div>

            <button
              onClick={() => setShowOptionsModal(false)}
              className="w-full py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold"
            >
              {t.cancel}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
