import React, { useState, useMemo } from 'react';
import { Heart, Search, BookOpen, Sparkles, Filter, ChevronRight } from 'lucide-react';
import { Story, AppLanguage } from '../types';
import { translations } from '../data/translations';
import { getAllStories } from '../data/stories';
import { StoryReader } from './StoryReader';

interface StoriesViewProps {
  currentLang: AppLanguage;
  favorites: string[];
  onToggleFavorite: (storyId: string) => void;
}

export const StoriesView: React.FC<StoriesViewProps> = ({
  currentLang,
  favorites,
  onToggleFavorite
}) => {
  const t = translations[currentLang] || translations.hi;
  const allStories = useMemo(() => getAllStories(), []);

  // UI state
  const [storyLanguage, setStoryLanguage] = useState<'hi' | 'en'>(
    currentLang === 'en' ? 'en' : 'hi'
  );
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showOnlyFavorites, setShowOnlyFavorites] = useState<boolean>(false);
  const [activeReadingStory, setActiveReadingStory] = useState<Story | null>(null);

  const categories = [
    { id: 'all', labelHi: 'सभी कथाएं', labelEn: 'All Stories' },
    { id: 'ramayana', labelHi: 'रामायण', labelEn: 'Ramayana' },
    { id: 'krishna', labelHi: 'श्री कृष्ण', labelEn: 'Sri Krishna' },
    { id: 'shiva', labelHi: 'महादेव शिव', labelEn: 'Lord Shiva' },
    { id: 'vishnu', labelHi: 'भगवान विष्णु', labelEn: 'Lord Vishnu' },
    { id: 'hanuman', labelHi: 'श्री हनुमान', labelEn: 'Hanuman' },
    { id: 'devi', labelHi: 'मां भगवती / देवी', labelEn: 'Devi Maa' },
    { id: 'bhakt', labelHi: 'भक्त व संत गाथा', labelEn: 'Bhakti & Saints' },
    { id: 'mahabharata', labelHi: 'महाभारत', labelEn: 'Mahabharata' },
    { id: 'gita', labelHi: 'भगवद्गीता', labelEn: 'Bhagavad Gita' },
    { id: 'puranas', labelHi: 'पुराण व ऋषि कथाएं', labelEn: 'Puranas' }
  ];

  // Filtered stories
  const filteredStories = useMemo(() => {
    return allStories.filter((s) => {
      // Category filter
      if (selectedCategory !== 'all' && s.category !== selectedCategory) {
        return false;
      }
      // Favorites filter
      if (showOnlyFavorites && !favorites.includes(s.id)) {
        return false;
      }
      // Search query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const titleMatch =
          s.title.hi.toLowerCase().includes(query) ||
          s.title.en.toLowerCase().includes(query);
        const deityMatch = s.deity.toLowerCase().includes(query);
        const summaryMatch =
          s.summary.hi.toLowerCase().includes(query) ||
          s.summary.en.toLowerCase().includes(query);
        if (!titleMatch && !deityMatch && !summaryMatch) {
          return false;
        }
      }
      return true;
    });
  }, [allStories, selectedCategory, showOnlyFavorites, favorites, searchQuery]);

  if (activeReadingStory) {
    return (
      <StoryReader
        story={activeReadingStory}
        allStories={filteredStories.length > 0 ? filteredStories : allStories}
        storyLanguage={storyLanguage}
        isFavorite={favorites.includes(activeReadingStory.id)}
        appLanguage={currentLang}
        onBack={() => setActiveReadingStory(null)}
        onToggleFavorite={onToggleFavorite}
        onNavigateStory={(nextS) => setActiveReadingStory(nextS)}
      />
    );
  }

  return (
    <div className="w-full min-h-screen bg-[#FFFBF0] flex flex-col pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-20 bg-[#FFFBF0]/95 backdrop-blur-md px-4 py-3 border-b border-amber-200/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-orange-600" />
          <h2 className="text-lg font-bold text-stone-900 font-hindi">
            {t.hinduStories}
          </h2>
          <span className="text-xs font-bold text-orange-600 bg-orange-100/80 px-2 py-0.5 rounded-full tabular-nums">
            {allStories.length}
          </span>
        </div>

        {/* Favourites Toggle Button */}
        <button
          onClick={() => setShowOnlyFavorites((prev) => !prev)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold active:scale-95 transition-all ${
            showOnlyFavorites
              ? 'bg-red-500 text-white border-red-600 shadow-xs'
              : 'bg-white text-stone-700 border-stone-200 hover:border-amber-300'
          }`}
          title="Favorites"
        >
          <Heart className={`w-3.5 h-3.5 ${showOnlyFavorites ? 'fill-white' : 'text-red-500 fill-red-500'}`} />
          <span>{t.favorites}</span>
          {favorites.length > 0 && (
            <span className={`text-[10px] font-bold ${showOnlyFavorites ? 'text-red-100' : 'text-stone-400'}`}>
              ({favorites.length})
            </span>
          )}
        </button>
      </div>

      <div className="p-4 space-y-4 max-w-md mx-auto w-full">
        {/* Story Language and Search Bar */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="खोजें / Search 140+ stories..."
              className="w-full pl-9 pr-3 py-2 bg-white border border-stone-200 rounded-2xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/40"
            />
          </div>

          {/* Language Switcher */}
          <div className="flex items-center bg-white border border-stone-200 rounded-2xl p-1 shrink-0">
            <button
              onClick={() => setStoryLanguage('hi')}
              className={`px-2.5 py-1 text-xs font-bold rounded-xl transition-all ${
                storyLanguage === 'hi'
                  ? 'bg-orange-500 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              हिं
            </button>
            <button
              onClick={() => setStoryLanguage('en')}
              className={`px-2.5 py-1 text-xs font-bold rounded-xl transition-all ${
                storyLanguage === 'en'
                  ? 'bg-orange-500 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              EN
            </button>
          </div>
        </div>

        {/* Category Pills Scroller */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
                selectedCategory === c.id
                  ? 'bg-stone-900 text-white shadow-xs'
                  : 'bg-white border border-stone-200 text-stone-600 hover:border-stone-300'
              }`}
            >
              {storyLanguage === 'hi' ? c.labelHi : c.labelEn}
            </button>
          ))}
        </div>

        {/* Stories List */}
        {filteredStories.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 border border-amber-200/80 text-center">
            <BookOpen className="w-10 h-10 text-stone-300 mx-auto mb-2" />
            <h4 className="font-bold text-stone-800 text-sm mb-1 font-hindi">
              कोई कथा नहीं मिली
            </h4>
            <p className="text-xs text-stone-500">
              कृपया अन्य श्रेणी या खोज शब्द चुनें।
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredStories.map((story) => {
              const isFav = favorites.includes(story.id);
              const title = storyLanguage === 'hi' ? story.title.hi : story.title.en;
              const summary = storyLanguage === 'hi' ? story.summary.hi : story.summary.en;

              return (
                <div
                  key={story.id}
                  className="bg-white rounded-3xl p-4 border border-amber-200/80 shadow-xs hover:border-orange-300 transition-all flex flex-col justify-between"
                >
                  <div>
                    {/* Header: Deity & Favorite button */}
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[11px] font-bold text-orange-600 uppercase tracking-wider font-sans">
                        {story.deity}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleFavorite(story.id);
                        }}
                        className="p-1.5 rounded-full hover:bg-stone-100 text-stone-400"
                        title="Add to Favorites"
                      >
                        <Heart
                          className={`w-4 h-4 ${isFav ? 'text-red-500 fill-red-500' : 'hover:text-red-500'}`}
                        />
                      </button>
                    </div>

                    {/* Title */}
                    <h3 className="font-bold text-base text-stone-900 mb-1.5 leading-snug font-devotional">
                      {title}
                    </h3>

                    {/* Excerpt */}
                    <p className="text-xs text-stone-600 leading-relaxed line-clamp-2 font-hindi mb-3">
                      {summary}
                    </p>
                  </div>

                  {/* Footer & Read Full Story Button */}
                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                    <span className="text-[10px] text-stone-400">
                      {story.readTimeMinutes} min read · {story.category}
                    </span>

                    <button
                      onClick={() => setActiveReadingStory(story)}
                      className="px-3 py-1.5 rounded-xl bg-orange-50 hover:bg-orange-100/80 text-orange-800 text-xs font-bold flex items-center gap-1 active:scale-95 transition-all"
                    >
                      <span>{t.readFullStory}</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
