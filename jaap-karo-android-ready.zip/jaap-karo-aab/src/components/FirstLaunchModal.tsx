import React from 'react';
import { AppLanguage } from '../types';
import { translations } from '../data/translations';
import { Sparkles, Check } from 'lucide-react';

interface FirstLaunchModalProps {
  currentLang: AppLanguage;
  onSelectLanguage: (lang: AppLanguage) => void;
  onContinue: () => void;
}

const languages: { code: AppLanguage; label: string; native: string }[] = [
  { code: 'hi', label: 'Hindi', native: 'हिंदी' },
  { code: 'en', label: 'English', native: 'English' },
  { code: 'sa', label: 'Sanskrit', native: 'संस्कृतम्' },
  { code: 'gu', label: 'Gujarati', native: 'ગુજરાતી' },
  { code: 'mr', label: 'Marathi', native: 'मराठी' },
  { code: 'bn', label: 'Bengali', native: 'বাংলা' },
  { code: 'te', label: 'Telugu', native: 'తెలుగు' },
  { code: 'ta', label: 'Tamil', native: 'தமிழ்' }
];

export const FirstLaunchModal: React.FC<FirstLaunchModalProps> = ({
  currentLang,
  onSelectLanguage,
  onContinue
}) => {
  const t = translations[currentLang] || translations.hi;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-[#FFFDF7] rounded-3xl p-6 shadow-2xl border border-amber-200/80 text-center flex flex-col items-center">
        {/* Sacred Icon Badge */}
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center shadow-lg shadow-orange-500/25 mb-4 text-white">
          <span className="font-devotional text-3xl font-bold">ॐ</span>
        </div>

        <h2 className="text-2xl font-bold text-stone-900 mb-1 font-devotional">
          {t.welcomeTitle}
        </h2>
        <p className="text-sm text-stone-600 mb-6 max-w-xs">
          {t.welcomeSubtitle}
        </p>

        {/* Language Grid */}
        <div className="w-full grid grid-cols-2 gap-2.5 mb-6">
          {languages.map((item) => {
            const isSelected = currentLang === item.code;
            return (
              <button
                key={item.code}
                onClick={() => onSelectLanguage(item.code)}
                className={`py-3 px-3 rounded-xl text-left border flex items-center justify-between transition-all ${
                  isSelected
                    ? 'border-orange-500 bg-orange-50/80 text-orange-950 shadow-sm ring-1 ring-orange-500/40'
                    : 'border-stone-200 bg-white hover:border-amber-300 text-stone-700'
                }`}
              >
                <div>
                  <div className="font-bold text-base leading-tight font-hindi">
                    {item.native}
                  </div>
                  <div className="text-xs text-stone-400">
                    {item.label}
                  </div>
                </div>
                {isSelected && (
                  <div className="w-5 h-5 rounded-full bg-orange-500 text-white flex items-center justify-center">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Continue Button */}
        <button
          onClick={onContinue}
          className="w-full h-12 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-semibold text-base shadow-md shadow-orange-500/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
        >
          <span>{t.continueBtn}</span>
          <Sparkles className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
