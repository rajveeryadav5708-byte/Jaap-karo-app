import React, { useState } from 'react';
import { RotateCcw, AlertTriangle, X, Check } from 'lucide-react';
import { AppLanguage } from '../types';
import { translations } from '../data/translations';

export type ResetType = 'beads' | 'today' | 'malas' | 'all';

interface ResetDialogProps {
  currentLang: AppLanguage;
  onConfirmReset: (type: ResetType) => void;
}

export const ResetDialog: React.FC<ResetDialogProps> = ({
  currentLang,
  onConfirmReset
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [pendingResetType, setPendingResetType] = useState<ResetType | null>(null);

  const t = translations[currentLang] || translations.hi;

  const resetOptions: {
    type: ResetType;
    title: string;
    desc: string;
    isDanger?: boolean;
  }[] = [
    {
      type: 'beads',
      title: t.resetBeadsTitle,
      desc: t.resetBeadsDesc
    },
    {
      type: 'today',
      title: t.resetTodayTitle,
      desc: t.resetTodayDesc
    },
    {
      type: 'malas',
      title: t.resetMalasTitle,
      desc: t.resetMalasDesc
    },
    {
      type: 'all',
      title: t.resetAllTitle,
      desc: t.resetAllDesc,
      isDanger: true
    }
  ];

  const handleSelectOption = (type: ResetType) => {
    setIsMenuOpen(false);
    setPendingResetType(type);
  };

  const handleConfirm = () => {
    if (pendingResetType) {
      onConfirmReset(pendingResetType);
      setPendingResetType(null);
    }
  };

  const activeOptionInfo = resetOptions.find((o) => o.type === pendingResetType);

  return (
    <>
      {/* Trigger Button */}
      <button
        onClick={() => setIsMenuOpen(true)}
        className="flex-1 h-12 rounded-2xl bg-white border border-stone-300 hover:border-amber-400 text-stone-700 font-bold text-xs uppercase tracking-wider shadow-xs active:scale-[0.98] transition-all flex items-center justify-center gap-2"
      >
        <RotateCcw className="w-4 h-4 text-stone-500" />
        <span className="font-hindi">{t.resetProgress}</span>
      </button>

      {/* Options Menu Modal */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-stone-950/60 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-amber-200">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-4">
              <h3 className="font-bold text-stone-900 text-base font-hindi">
                {t.resetMenuTitle}
              </h3>
              <button
                onClick={() => setIsMenuOpen(false)}
                className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5">
              {resetOptions.map((opt) => (
                <button
                  key={opt.type}
                  onClick={() => handleSelectOption(opt.type)}
                  className={`w-full p-3.5 text-left rounded-2xl border transition-all ${
                    opt.isDanger
                      ? 'border-red-200 bg-red-50/60 text-red-900 hover:bg-red-100/70'
                      : 'border-stone-200 bg-stone-50/80 hover:border-amber-300 text-stone-800'
                  }`}
                >
                  <div className="font-bold text-sm font-hindi">
                    {opt.title}
                  </div>
                  <div className="text-xs text-stone-500 mt-0.5 line-clamp-2">
                    {opt.desc}
                  </div>
                </button>
              ))}
            </div>

            <button
              onClick={() => setIsMenuOpen(false)}
              className="w-full mt-4 py-3 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs"
            >
              {t.cancel}
            </button>
          </div>
        </div>
      )}

      {/* Confirmation Dialog */}
      {pendingResetType && activeOptionInfo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/70 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-amber-200 text-center">
            <div
              className={`w-14 h-14 rounded-2xl mx-auto flex items-center justify-center mb-4 ${
                activeOptionInfo.isDanger
                  ? 'bg-red-100 text-red-600'
                  : 'bg-amber-100 text-orange-600'
              }`}
            >
              <AlertTriangle className="w-7 h-7" />
            </div>

            <h4 className="font-bold text-stone-900 text-lg mb-2 font-hindi">
              {activeOptionInfo.title}
            </h4>

            <p className="text-xs text-stone-600 leading-relaxed mb-6">
              {activeOptionInfo.desc}
            </p>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setPendingResetType(null)}
                className="py-3 px-4 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 font-bold text-sm"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleConfirm}
                className={`py-3 px-4 rounded-xl font-bold text-sm text-white shadow-xs ${
                  activeOptionInfo.isDanger
                    ? 'bg-red-600 hover:bg-red-700 shadow-red-500/20'
                    : 'bg-orange-500 hover:bg-orange-600 shadow-orange-500/20'
                }`}
              >
                {t.confirm}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
