import React, { useState } from 'react';
import { ArrowLeft, Flame, Award, ChevronLeft, ChevronRight, Check } from 'lucide-react';
import { AppLanguage } from '../types';
import { translations } from '../data/translations';
import { getTodayDateString } from '../utils/storage';

interface StreakViewProps {
  currentStreak: number;
  bestStreak: number;
  dailyHistory: Record<string, number>;
  todayChants: number;
  currentLang: AppLanguage;
  onBack: () => void;
}

export const StreakView: React.FC<StreakViewProps> = ({
  currentStreak,
  bestStreak,
  dailyHistory,
  todayChants,
  currentLang,
  onBack
}) => {
  const t = translations[currentLang] || translations.hi;
  const todayStr = getTodayDateString();

  // Full activity map including today's live chants
  const combinedHistory: Record<string, number> = {
    ...dailyHistory,
    ...(todayChants > 0 ? { [todayStr]: (dailyHistory[todayStr] || 0) + todayChants } : {})
  };

  // State for monthly calendar view navigation
  const [currentCalendarDate, setCurrentCalendarDate] = useState(new Date());

  const currentYear = currentCalendarDate.getFullYear();
  const currentMonth = currentCalendarDate.getMonth(); // 0-indexed

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const handlePrevMonth = () => {
    setCurrentCalendarDate(new Date(currentYear, currentMonth - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentCalendarDate(new Date(currentYear, currentMonth + 1, 1));
  };

  // Build This Week days (Monday to Sunday)
  const weekDays = (() => {
    const today = new Date();
    // In JS getDay(): 0 is Sunday, 1 is Monday ... 6 is Saturday
    const currentDayOfWeek = today.getDay();
    // Calculate distance back to Monday
    const distanceToMonday = currentDayOfWeek === 0 ? 6 : currentDayOfWeek - 1;
    const monday = new Date(today);
    monday.setDate(today.getDate() - distanceToMonday);

    const days = [];
    const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const hindiLabels = ['सोम', 'मंगल', 'बुध', 'गुरु', 'शुक्र', 'शनि', 'रवि'];

    for (let i = 0; i < 7; i++) {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const dayNum = String(d.getDate()).padStart(2, '0');
      const dateKey = `${y}-${m}-${dayNum}`;

      const count = combinedHistory[dateKey] || 0;
      const isCompleted = count > 0;
      const isToday = dateKey === todayStr;

      days.push({
        dateKey,
        dayNumber: d.getDate(),
        shortLabel: currentLang === 'hi' ? hindiLabels[i] : labels[i],
        isCompleted,
        isToday,
        count
      });
    }
    return days;
  })();

  // Build Monthly Calendar Grid
  const calendarGrid = (() => {
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
    // Monday as first column (0): shift Sunday (0) to index 6, Monday (1) to 0
    const startOffset = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1;
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

    const cells = [];
    // Padding empty cells before day 1
    for (let i = 0; i < startOffset; i++) {
      cells.push(null);
    }
    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const mStr = String(currentMonth + 1).padStart(2, '0');
      const dStr = String(day).padStart(2, '0');
      const dateKey = `${currentYear}-${mStr}-${dStr}`;
      const count = combinedHistory[dateKey] || 0;
      const isCompleted = count > 0;
      const isToday = dateKey === todayStr;

      cells.push({
        day,
        dateKey,
        isCompleted,
        isToday,
        count
      });
    }
    return cells;
  })();

  return (
    <div className="w-full min-h-screen bg-[#FFFBF0] flex flex-col pb-24">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-[#FFFBF0]/95 backdrop-blur-md px-4 py-3 border-b border-amber-200/80 flex items-center justify-between">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-white border border-stone-200 flex items-center justify-center text-stone-700 active:scale-95 transition-all shadow-xs"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="text-lg font-bold text-stone-900 font-hindi">
          {t.streak} & {t.monthlyCalendar}
        </h2>
        <div className="w-10" />
      </div>

      <div className="p-4 space-y-4 max-w-md mx-auto w-full">
        {/* Top Two Streak Cards */}
        <div className="grid grid-cols-2 gap-3">
          {/* Current Streak */}
          <div className="bg-gradient-to-br from-amber-500 to-orange-500 text-white rounded-3xl p-4 shadow-md shadow-orange-500/20 text-center relative overflow-hidden">
            <div className="w-10 h-10 rounded-2xl bg-white/20 mx-auto flex items-center justify-center mb-1">
              <Flame className="w-6 h-6 fill-white text-white" />
            </div>
            <div className="text-3xl font-extrabold tabular-nums font-sans">
              {currentStreak}
            </div>
            <div className="text-xs font-semibold uppercase tracking-wider text-amber-100 mt-0.5 font-hindi">
              {t.currentStreakLabel}
            </div>
            <div className="text-[11px] text-white/80">
              {t.days} {t.streak}
            </div>
          </div>

          {/* Best Streak */}
          <div className="bg-white rounded-3xl p-4 border border-amber-200/80 shadow-xs text-center">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-700 mx-auto flex items-center justify-center mb-1">
              <Award className="w-6 h-6" />
            </div>
            <div className="text-3xl font-extrabold text-stone-900 tabular-nums font-sans">
              {bestStreak}
            </div>
            <div className="text-xs font-semibold uppercase tracking-wider text-stone-500 mt-0.5 font-hindi">
              {t.bestStreakLabel}
            </div>
            <div className="text-[11px] text-stone-400">
              {t.days} {t.streak}
            </div>
          </div>
        </div>

        {/* This Week Section */}
        <div className="bg-white rounded-3xl p-4 border border-amber-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-sm text-stone-900 font-hindi">
              {t.thisWeek}
            </h3>
            <span className="text-xs text-orange-600 font-medium">
              {weekDays.filter((d) => d.isCompleted).length} / 7 {t.days}
            </span>
          </div>

          <div className="grid grid-cols-7 gap-1.5 text-center">
            {weekDays.map((d) => (
              <div
                key={d.dateKey}
                className={`py-2 px-1 rounded-2xl flex flex-col items-center justify-between border transition-all ${
                  d.isToday
                    ? 'border-orange-500 bg-orange-50/60 ring-1 ring-orange-500/30'
                    : 'border-stone-100 bg-stone-50/60'
                }`}
              >
                <span className="text-[10px] font-bold text-stone-400 uppercase">
                  {d.shortLabel}
                </span>
                <span className={`text-sm font-bold my-1 ${d.isToday ? 'text-orange-600' : 'text-stone-700'}`}>
                  {d.dayNumber}
                </span>

                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                    d.isCompleted
                      ? 'bg-orange-500 text-white shadow-xs'
                      : 'bg-stone-200/80 text-stone-300'
                  }`}
                >
                  {d.isCompleted ? (
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  ) : (
                    <span className="w-1.5 h-1.5 rounded-full bg-stone-300" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Monthly Calendar */}
        <div className="bg-white rounded-3xl p-4 border border-amber-200/80 shadow-xs">
          {/* Calendar Header with Navigation */}
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={handlePrevMonth}
              className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-700"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <h3 className="font-bold text-sm text-stone-900">
              {monthNames[currentMonth]} {currentYear}
            </h3>

            <button
              onClick={handleNextMonth}
              className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-700"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Weekday Column Headers */}
          <div className="grid grid-cols-7 gap-1 text-center mb-2">
            {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((dayChar, i) => (
              <span key={i} className="text-[11px] font-bold text-stone-400">
                {dayChar}
              </span>
            ))}
          </div>

          {/* Day Grid */}
          <div className="grid grid-cols-7 gap-1 text-center">
            {calendarGrid.map((cell, idx) => {
              if (!cell) {
                return <div key={`empty-${idx}`} className="h-10" />;
              }

              return (
                <div
                  key={cell.dateKey}
                  className={`h-11 rounded-xl flex flex-col items-center justify-center relative border transition-all ${
                    cell.isToday
                      ? 'border-orange-500 bg-orange-50/70 font-bold'
                      : cell.isCompleted
                      ? 'border-amber-200 bg-amber-50/40'
                      : 'border-transparent text-stone-700'
                  }`}
                  title={`${cell.dateKey}: ${cell.count} chants`}
                >
                  <span className={`text-xs ${cell.isToday ? 'text-orange-600 font-bold' : 'text-stone-800'}`}>
                    {cell.day}
                  </span>

                  {cell.isCompleted && (
                    <div className="w-4 h-4 rounded-full bg-orange-500 text-white flex items-center justify-center mt-0.5">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
