import React from 'react';
import { Flame } from 'lucide-react';
import { AppLanguage } from '../types';
import { translations } from '../data/translations';

interface HeaderProps {
  currentLang: AppLanguage;
  streakCount: number;
  onOpenStreak: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentLang,
  streakCount,
  onOpenStreak
}) => {
  const t = translations[currentLang] || translations.hi;

  return (
    <header className="sticky top-0 z-30 w-full bg-[#FFFBF0]/95 backdrop-blur-md px-4 py-3 border-b border-amber-100 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-orange-500/10 text-orange-600 flex items-center justify-center font-bold text-lg font-devotional">
          ॐ
        </div>
        <h1 className="text-lg font-bold text-stone-900 tracking-tight font-hindi">
          {t.naamJapCounter}
        </h1>
      </div>

      <button
        onClick={onOpenStreak}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-orange-100/80 border border-orange-300 text-orange-800 text-xs font-semibold hover:bg-orange-200/80 active:scale-95 transition-all shadow-xs"
        title={t.streak}
      >
        <Flame className="w-4 h-4 text-orange-500 fill-orange-500 animate-pulse" />
        <span className="font-bold text-sm tabular-nums text-stone-900">
          {streakCount}
        </span>
        <span className="text-[11px] text-orange-700 font-medium">
          {t.days}
        </span>
      </button>
    </header>
  );
};
