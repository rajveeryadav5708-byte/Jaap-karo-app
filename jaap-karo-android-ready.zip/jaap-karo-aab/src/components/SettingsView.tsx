import React, { useState } from 'react';
import {
  Globe,
  Target,
  Gauge,
  Vibrate,
  Bell,
  Bookmark,
  Star,
  Share2,
  Mail,
  Shield,
  KeyRound,
  Info,
  ChevronRight,
  X,
  Check
} from 'lucide-react';
import { AppLanguage, AppSettings } from '../types';
import { translations } from '../data/translations';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
}

const languagesList: { code: AppLanguage; label: string; native: string }[] = [
  { code: 'hi', label: 'Hindi', native: 'हिंदी' },
  { code: 'en', label: 'English', native: 'English' },
  { code: 'sa', label: 'Sanskrit', native: 'संस्कृतम्' },
  { code: 'gu', label: 'Gujarati', native: 'ગુજરાતી' },
  { code: 'mr', label: 'Marathi', native: 'मराठी' },
  { code: 'bn', label: 'Bengali', native: 'বাংলা' },
  { code: 'te', label: 'Telugu', native: 'తెలుగు' },
  { code: 'ta', label: 'Tamil', native: 'தமிழ்' }
];

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings
}) => {
  const t = translations[settings.language] || translations.hi;

  // Active modal state
  const [activeModal, setActiveModal] = useState<
    'language' | 'goal' | 'speed' | 'privacy' | 'permissions' | 'about' | 'rate' | null
  >(null);
  const [customGoalInput, setCustomGoalInput] = useState<string>('');
  const [shareSuccessToast, setShareSuccessToast] = useState<string | null>(null);

  // Handle Share App
  const handleShareApp = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: 'Jaap Karo - Naam Jap Counter',
          text: 'Join me in daily spiritual chanting with the 108-bead Mala counter and sacred stories on Jaap Karo!',
          url: window.location.href
        });
      } catch {
        // User cancelled share
      }
    } else {
      // Fallback copy to clipboard
      try {
        await navigator.clipboard.writeText(window.location.href);
        setShareSuccessToast('Link copied to clipboard!');
        setTimeout(() => setShareSuccessToast(null), 2500);
      } catch {
        // Clipboard fallback
      }
    }
  };

  // Handle Contact Us Email
  const handleContactUs = () => {
    window.location.href =
      'mailto:Rajveeryadav5708@gmail.com?subject=Jaap%20Karo%20App%20Feedback&body=Pranam,%0A%0A';
  };

  return (
    <div className="w-full min-h-screen bg-[#FFFBF0] flex flex-col pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-20 bg-[#FFFBF0]/95 backdrop-blur-md px-4 py-3 border-b border-amber-200/80 flex items-center justify-between">
        <h2 className="text-lg font-bold text-stone-900 font-hindi">
          {t.settings}
        </h2>
      </div>

      <div className="p-4 space-y-5 max-w-md mx-auto w-full">
        {/* Toast Notification */}
        {shareSuccessToast && (
          <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 rounded-2xl text-xs font-bold text-center animate-in fade-in">
            {shareSuccessToast}
          </div>
        )}

        {/* Section 1: General Settings */}
        <div>
          <h3 className="text-xs font-bold text-stone-500 uppercase tracking-wider mb-2 font-sans px-1">
            {t.generalSettings}
          </h3>

          <div className="bg-white rounded-3xl border border-amber-200/80 shadow-xs divide-y divide-stone-100 overflow-hidden">
            {/* 1. Language */}
            <button
              onClick={() => setActiveModal('language')}
              className="w-full p-4 text-left flex items-center justify-between hover:bg-stone-50 active:bg-stone-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
                  <Globe className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-sm text-stone-900 block font-hindi">
                    {t.language}
                  </span>
                  <span className="text-xs text-stone-500 font-hindi">
                    {languagesList.find((l) => l.code === settings.language)?.native} ({languagesList.find((l) => l.code === settings.language)?.label})
                  </span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-stone-400" />
            </button>

            {/* 2. Daily Goal */}
            <button
              onClick={() => setActiveModal('goal')}
              className="w-full p-4 text-left flex items-center justify-between hover:bg-stone-50 active:bg-stone-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                  <Target className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-sm text-stone-900 block font-hindi">
                    {t.dailyJaapGoal}
                  </span>
                  <span className="text-xs text-stone-500">
                    {settings.dailyGoalMalas} {settings.dailyGoalMalas === 1 ? 'Mala' : 'Malas'} ({settings.dailyGoalMalas * 108} chants)
                  </span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-stone-400" />
            </button>

            {/* 3. Auto Jaap Speed */}
            <button
              onClick={() => setActiveModal('speed')}
              className="w-full p-4 text-left flex items-center justify-between hover:bg-stone-50 active:bg-stone-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
                  <Gauge className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-sm text-stone-900 block font-hindi">
                    {t.autoJaapSpeedLabel}
                  </span>
                  <span className="text-xs text-stone-500">
                    {settings.autoJaapSpeed} seconds per chant
                  </span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-stone-400" />
            </button>

            {/* 4. Haptics Vibration Toggle */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <Vibrate className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-sm text-stone-900 block font-hindi">
                    {t.haptics}
                  </span>
                  <span className="text-xs text-stone-400">
                    Vibrate on each bead tap
                  </span>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.hapticsEnabled}
                  onChange={(e) => onUpdateSettings({ hapticsEnabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-stone-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-500" />
              </label>
            </div>

            {/* 5. Daily Notifications & Reminder Time */}
            <div className="p-4 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
                    <Bell className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-sm text-stone-900 block font-hindi">
                      {t.notifications}
                    </span>
                    <span className="text-xs text-stone-400">
                      Brahma Muhurta / daily alert
                    </span>
                  </div>
                </div>

                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.notificationsEnabled}
                    onChange={(e) => onUpdateSettings({ notificationsEnabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-stone-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-500" />
                </label>
              </div>

              {settings.notificationsEnabled && (
                <div className="pl-12 flex items-center justify-between pt-1">
                  <span className="text-xs text-stone-600 font-hindi">
                    {t.reminderTime}:
                  </span>
                  <input
                    type="time"
                    value={settings.reminderTime}
                    onChange={(e) => onUpdateSettings({ reminderTime: e.target.value })}
                    className="text-xs font-bold bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-1 text-stone-800"
                  />
                </div>
              )}
            </div>

            {/* 6. Remember Last Visited Page */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <Bookmark className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-sm text-stone-900 block font-hindi">
                    {t.rememberLastPage}
                  </span>
                  <span className="text-xs text-stone-400">
                    Restore active tab on open
                  </span>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.rememberLastPage}
                  onChange={(e) => onUpdateSettings({ rememberLastPage: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-stone-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-500" />
              </label>
            </div>
          </div>
        </div>

        {/* Section 2: Other Settings */}
        <div>
          <h3 className="text-xs font-bold text-stone-500 uppercase tracking-wider mb-2 font-sans px-1">
            More Information & Support
          </h3>

          <div className="bg-white rounded-3xl border border-amber-200/80 shadow-xs divide-y divide-stone-100 overflow-hidden">
            {/* Rate Us */}
            <button
              onClick={() => setActiveModal('rate')}
              className="w-full p-4 text-left flex items-center justify-between hover:bg-stone-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                </div>
                <span className="font-bold text-sm text-stone-900 font-hindi">
                  {t.rateUs}
                </span>
              </div>
              <ChevronRight className="w-4 h-4 text-stone-400" />
            </button>

            {/* Share App */}
            <button
              onClick={handleShareApp}
              className="w-full p-4 text-left flex items-center justify-between hover:bg-stone-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <Share2 className="w-4 h-4" />
                </div>
                <span className="font-bold text-sm text-stone-900 font-hindi">
                  {t.shareApp}
                </span>
              </div>
              <ChevronRight className="w-4 h-4 text-stone-400" />
            </button>

            {/* Contact Us */}
            <button
              onClick={handleContactUs}
              className="w-full p-4 text-left flex items-center justify-between hover:bg-stone-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-sm text-stone-900 block font-hindi">
                    {t.contactUs}
                  </span>
                  <span className="text-xs text-stone-400 font-mono">
                    Rajveeryadav5708@gmail.com
                  </span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-stone-400" />
            </button>

            {/* Privacy Policy */}
            <button
              onClick={() => setActiveModal('privacy')}
              className="w-full p-4 text-left flex items-center justify-between hover:bg-stone-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <Shield className="w-4 h-4" />
                </div>
                <span className="font-bold text-sm text-stone-900 font-hindi">
                  {t.privacyPolicy}
                </span>
              </div>
              <ChevronRight className="w-4 h-4 text-stone-400" />
            </button>

            {/* Permissions Used */}
            <button
              onClick={() => setActiveModal('permissions')}
              className="w-full p-4 text-left flex items-center justify-between hover:bg-stone-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <KeyRound className="w-4 h-4" />
                </div>
                <span className="font-bold text-sm text-stone-900 font-hindi">
                  {t.permissionsUsed}
                </span>
              </div>
              <ChevronRight className="w-4 h-4 text-stone-400" />
            </button>

            {/* About App */}
            <button
              onClick={() => setActiveModal('about')}
              className="w-full p-4 text-left flex items-center justify-between hover:bg-stone-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center">
                  <Info className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-sm text-stone-900 block font-hindi">
                    {t.aboutApp}
                  </span>
                  <span className="text-xs text-stone-400 font-sans">
                    Version 1.0.0
                  </span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-stone-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Language Selection Modal */}
      {activeModal === 'language' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-amber-200">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-3">
              <h3 className="font-bold text-stone-900 text-base font-hindi">
                {t.language}
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="w-7 h-7 rounded-full bg-stone-100 flex items-center justify-center text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 mb-4">
              {languagesList.map((lang) => {
                const isSelected = settings.language === lang.code;
                return (
                  <button
                    key={lang.code}
                    onClick={() => {
                      onUpdateSettings({ language: lang.code });
                      setActiveModal(null);
                    }}
                    className={`p-3 rounded-2xl border text-left flex items-center justify-between transition-all ${
                      isSelected
                        ? 'border-orange-500 bg-orange-50 text-orange-950 font-bold'
                        : 'border-stone-200 hover:border-amber-300'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-sm font-hindi">{lang.native}</div>
                      <div className="text-[10px] text-stone-400">{lang.label}</div>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-orange-600" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Daily Goal Modal */}
      {activeModal === 'goal' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-amber-200">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-3">
              <h3 className="font-bold text-stone-900 text-base font-hindi">
                {t.dailyJaapGoal}
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="w-7 h-7 rounded-full bg-stone-100 flex items-center justify-center text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-stone-500 mb-4">
              प्रतिदिन माला का लक्ष्य निर्धारित करें (1 माला = 108 मंत्र जाप)
            </p>

            <div className="grid grid-cols-4 gap-2 mb-4">
              {[1, 2, 5, 11].map((cnt) => (
                <button
                  key={cnt}
                  onClick={() => {
                    onUpdateSettings({ dailyGoalMalas: cnt });
                    setActiveModal(null);
                  }}
                  className={`py-3 rounded-2xl border font-bold text-sm text-center ${
                    settings.dailyGoalMalas === cnt
                      ? 'border-orange-500 bg-orange-50 text-orange-950'
                      : 'border-stone-200 hover:border-amber-300 text-stone-700'
                  }`}
                >
                  {cnt}
                </button>
              ))}
            </div>

            {/* Custom Goal */}
            <div className="flex gap-2">
              <input
                type="number"
                min="1"
                max="108"
                placeholder="कस्टम माला लक्ष्य..."
                value={customGoalInput}
                onChange={(e) => setCustomGoalInput(e.target.value)}
                className="flex-1 px-3 py-2 text-sm bg-stone-50 border border-stone-200 rounded-xl"
              />
              <button
                onClick={() => {
                  const val = parseInt(customGoalInput, 10);
                  if (val > 0) {
                    onUpdateSettings({ dailyGoalMalas: val });
                    setActiveModal(null);
                  }
                }}
                className="px-4 py-2 bg-orange-500 text-white font-bold text-xs rounded-xl"
              >
                सेव करें
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Auto Speed Modal */}
      {activeModal === 'speed' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-amber-200">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-3">
              <h3 className="font-bold text-stone-900 text-base font-hindi">
                {t.autoJaapSpeedLabel}
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="w-7 h-7 rounded-full bg-stone-100 flex items-center justify-center text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-stone-500 mb-4">
              ऑटो जाप में प्रत्येक मंत्र के बीच का समयांतराल (सेकंड में)
            </p>

            <div className="grid grid-cols-4 gap-2 mb-4">
              {[0.8, 1.0, 1.5, 2.0].map((spd) => (
                <button
                  key={spd}
                  onClick={() => {
                    onUpdateSettings({ autoJaapSpeed: spd });
                    setActiveModal(null);
                  }}
                  className={`py-3 rounded-2xl border font-bold text-sm ${
                    settings.autoJaapSpeed === spd
                      ? 'border-orange-500 bg-orange-50 text-orange-950'
                      : 'border-stone-200 hover:border-amber-300 text-stone-700'
                  }`}
                >
                  {spd}s
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Rate Us Modal */}
      {activeModal === 'rate' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-amber-200 text-center">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-500 mx-auto flex items-center justify-center mb-3">
              <Star className="w-7 h-7 fill-amber-400" />
            </div>
            <h3 className="font-bold text-stone-900 text-lg mb-1 font-hindi">
              रेट करें (Google Play)
            </h3>
            <p className="text-xs text-stone-600 mb-4 leading-relaxed">
              यदि जाप करो ऐप आपके दैनिक आध्यात्मिक जीवन में सहायक सिद्ध हुआ है, तो कृपया 5 स्टार रेटिंग देकर हमारा उत्साहवर्धन करें!
            </p>

            <div className="flex items-center justify-center gap-2 mb-6">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} className="w-7 h-7 fill-amber-400 text-amber-400 cursor-pointer hover:scale-110 transition-transform" />
              ))}
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-3 rounded-2xl bg-orange-500 text-white font-bold text-sm shadow-xs"
            >
              धन्यवाद (Submit)
            </button>
          </div>
        </div>
      )}

      {/* Privacy Policy Modal */}
      {activeModal === 'privacy' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-amber-200 max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-3">
              <h3 className="font-bold text-stone-900 text-base font-hindi">
                {t.privacyPolicy}
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="w-7 h-7 rounded-full bg-stone-100 flex items-center justify-center text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-y-auto space-y-3 text-xs text-stone-600 leading-relaxed font-hindi pr-1">
              <p className="font-bold text-stone-800">
                आपकी गोपनीयता हमारी सर्वोच्च प्राथमिकता है।
              </p>
              <p>
                1. <strong>स्थानीय डेटा संग्रहण (Local Storage):</strong> आपका समस्त जाप रिकॉर्ड, स्ट्रीक, मंत्र चयन और सेटिंग्स पूर्णतः आपके अपने फोन पर स्थानीय रूप से सुरक्षित रहती हैं।
              </p>
              <p>
                2. <strong>शून्य क्लाउड ट्रैकिंग:</strong> हम आपकी कोई भी व्यक्तिगत जानकारी किसी भी बाहरी या सार्वजनिक सर्वर पर नहीं भेजते हैं।
              </p>
              <p>
                3. <strong>पूर्ण नियंत्रण:</strong> आप जब चाहें ऐप सेटिंग्स से अपनी प्रगति को रीसेट या परिवर्तित कर सकते हैं।
              </p>
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full mt-4 py-2.5 rounded-xl bg-stone-100 text-stone-800 font-bold text-xs"
            >
              बंद करें
            </button>
          </div>
        </div>
      )}

      {/* Permissions Used Modal */}
      {activeModal === 'permissions' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-amber-200 max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-3">
              <h3 className="font-bold text-stone-900 text-base font-hindi">
                {t.permissionsUsed}
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="w-7 h-7 rounded-full bg-stone-100 flex items-center justify-center text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-y-auto space-y-3 text-xs text-stone-600 leading-relaxed pr-1 font-hindi">
              <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-100">
                <span className="font-bold text-stone-800 block">1. कंपन (Vibration / Haptics):</span>
                <span>मनका फेरते समय रुद्राक्ष माला के स्पर्श का अहसास कराने के लिए।</span>
              </div>

              <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-100">
                <span className="font-bold text-stone-800 block">2. दैनिक सूचनाएं (Notifications):</span>
                <span>आपके निर्धारित समय (जैसे ब्रह्म मुहूर्त) पर प्रतिदिन नाम जप का स्मरण कराने के लिए।</span>
              </div>

              <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-100">
                <span className="font-bold text-stone-800 block">3. ऑडियो व ध्वनि (Audio Playback):</span>
                <span>मंत्र उच्चारण, शंख ध्वनि एवं कथा वाचन (TTS) श्रवण हेतु।</span>
              </div>
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full mt-4 py-2.5 rounded-xl bg-stone-100 text-stone-800 font-bold text-xs"
            >
              समझ गया
            </button>
          </div>
        </div>
      )}

      {/* About App Modal */}
      {activeModal === 'about' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-amber-200 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 text-white mx-auto flex items-center justify-center shadow-md mb-3 text-2xl font-bold font-devotional">
              ॐ
            </div>

            <h3 className="font-bold text-stone-900 text-xl font-hindi mb-1">
              जाप करो (Jaap Karo)
            </h3>
            <span className="text-xs text-orange-600 font-semibold block mb-3 font-sans">
              Version 1.0.0 (Production Release)
            </span>

            <p className="text-xs text-stone-600 leading-relaxed font-hindi mb-4">
              यह ऐप सनातन धर्म के साधकों, भक्तों और नाम जप प्रेमियों के लिए तैयार किया गया है। इसमें 108 मनकों की डिजिटल रुद्राक्ष माला, दैनिक स्ट्रीक, 140+ पौराणिक कथाएं और दिव्य ध्वनि सम्मिलित हैं।
            </p>

            <div className="bg-stone-50 rounded-2xl p-3 border border-stone-100 text-xs text-stone-600 space-y-1 mb-4 text-left font-mono">
              <div><strong>Developer:</strong> Rajveer Yadav</div>
              <div><strong>Email:</strong> Rajveeryadav5708@gmail.com</div>
              <div><strong>Purpose:</strong> Devotional Chanting & Peace</div>
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-2.5 rounded-xl bg-orange-500 text-white font-bold text-xs"
            >
              हरि ॐ तत्सत्
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
