import React, { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight, BarChart3, TrendingUp, Calendar, Zap, Sparkles } from 'lucide-react';
import { AppLanguage } from '../types';
import { translations } from '../data/translations';
import { predefinedMantras } from '../data/mantras';
import { getTodayDateString } from '../utils/storage';

interface StatsViewProps {
  currentLang: AppLanguage;
  dailyHistory: Record<string, number>;
  todayChants: number;
  todayMalas: number;
  currentStreak: number;
  bestStreak: number;
  selectedMantra: string;
}

type TimeFilter = 'weekly' | 'monthly' | 'yearly';

export const StatsView: React.FC<StatsViewProps> = ({
  currentLang,
  dailyHistory,
  todayChants,
  todayMalas,
  currentStreak,
  bestStreak,
  selectedMantra
}) => {
  const t = translations[currentLang] || translations.hi;
  const [filter, setFilter] = useState<TimeFilter>('weekly');
  const [activeMantraFilter, setActiveMantraFilter] = useState<string>('ALL');
  const [periodOffset, setPeriodOffset] = useState<number>(0); // 0 = current period, -1 = previous, etc.
  const [activeTooltip, setActiveTooltip] = useState<{ label: string; count: number } | null>(null);

  const todayStr = getTodayDateString();

  // Combine saved history with today's live chants
  const combinedHistory = useMemo(() => {
    return {
      ...dailyHistory,
      ...(todayChants > 0 ? { [todayStr]: (dailyHistory[todayStr] || 0) + todayChants } : {})
    };
  }, [dailyHistory, todayChants, todayStr]);

  // Compute date range and chart data based on active filter and offset
  const { dateRangeLabel, barData, periodTotal, dailyAverage } = useMemo(() => {
    const today = new Date();

    if (filter === 'weekly') {
      // Calculate Monday of target week
      const targetDate = new Date(today);
      targetDate.setDate(today.getDate() + periodOffset * 7);

      const dayOfWeek = targetDate.getDay();
      const distToMon = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
      const monday = new Date(targetDate);
      monday.setDate(targetDate.getDate() - distToMon);

      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);

      const rangeLabel = `${monday.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} - ${sunday.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}`;

      const daysOfWeekLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      const data = [];
      let total = 0;

      for (let i = 0; i < 7; i++) {
        const d = new Date(monday);
        d.setDate(monday.getDate() + i);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const dayNum = String(d.getDate()).padStart(2, '0');
        const dKey = `${y}-${m}-${dayNum}`;

        const count = combinedHistory[dKey] || 0;
        total += count;
        data.push({
          label: daysOfWeekLabels[i],
          subLabel: String(d.getDate()),
          dateKey: dKey,
          count
        });
      }

      return {
        dateRangeLabel: rangeLabel,
        barData: data,
        periodTotal: total,
        dailyAverage: Math.round(total / 7)
      };
    } else if (filter === 'monthly') {
      const targetDate = new Date(today.getFullYear(), today.getMonth() + periodOffset, 1);
      const year = targetDate.getFullYear();
      const month = targetDate.getMonth();
      const daysInMonth = new Date(year, month + 1, 0).getDate();

      const rangeLabel = `${targetDate.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}`;

      const data = [];
      let total = 0;

      for (let day = 1; day <= daysInMonth; day++) {
        const mStr = String(month + 1).padStart(2, '0');
        const dStr = String(day).padStart(2, '0');
        const dKey = `${year}-${mStr}-${dStr}`;

        const count = combinedHistory[dKey] || 0;
        total += count;
        data.push({
          label: String(day),
          subLabel: '',
          dateKey: dKey,
          count
        });
      }

      return {
        dateRangeLabel: rangeLabel,
        barData: data,
        periodTotal: total,
        dailyAverage: Math.round(total / daysInMonth)
      };
    } else {
      // Yearly
      const targetYear = today.getFullYear() + periodOffset;
      const rangeLabel = `${targetYear}`;
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const data = [];
      let total = 0;

      for (let m = 0; m < 12; m++) {
        let mTotal = 0;
        const mStr = String(m + 1).padStart(2, '0');
        Object.entries(combinedHistory).forEach(([k, v]) => {
          if (k.startsWith(`${targetYear}-${mStr}`)) {
            mTotal += v;
          }
        });
        total += mTotal;
        data.push({
          label: months[m],
          subLabel: '',
          dateKey: `${targetYear}-${mStr}`,
          count: mTotal
        });
      }

      return {
        dateRangeLabel: rangeLabel,
        barData: data,
        periodTotal: total,
        dailyAverage: Math.round(total / 365)
      };
    }
  }, [filter, periodOffset, combinedHistory]);

  // Calculate highest bar value for proportional scaling
  const maxBarValue = useMemo(() => {
    const highest = Math.max(...barData.map((d) => d.count), 0);
    return highest > 0 ? highest : 108;
  }, [barData]);

  // Overall lifetime aggregate metrics
  const lifetimeMetrics = useMemo(() => {
    const dates = Object.keys(combinedHistory);
    const totalDays = dates.filter((k) => combinedHistory[k] > 0).length;
    let totalAllChants = 0;
    let mostActiveCount = 0;
    let mostActiveDayStr = 'None';

    dates.forEach((d) => {
      const cnt = combinedHistory[d];
      totalAllChants += cnt;
      if (cnt > mostActiveCount) {
        mostActiveCount = cnt;
        mostActiveDayStr = d;
      }
    });

    const lifetimeMalas = Math.floor(totalAllChants / 108);
    const avgDaily = totalDays > 0 ? Math.round(totalAllChants / totalDays) : 0;

    return {
      totalJaap: totalAllChants,
      totalMalas: lifetimeMalas,
      totalDays,
      avgDaily,
      mostActiveDayStr: mostActiveDayStr !== 'None' ? mostActiveDayStr : todayStr,
      mostActiveCount
    };
  }, [combinedHistory, todayStr]);

  return (
    <div className="w-full min-h-screen bg-[#FFFBF0] flex flex-col pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-20 bg-[#FFFBF0]/95 backdrop-blur-md px-4 py-3 border-b border-amber-200/80 flex items-center justify-between">
        <h2 className="text-lg font-bold text-stone-900 font-hindi">
          {t.progress}
        </h2>

        {/* Period Navigation */}
        <div className="flex items-center gap-1 bg-white border border-amber-200 rounded-full p-1 shadow-xs">
          <button
            onClick={() => setPeriodOffset((prev) => prev - 1)}
            className="w-7 h-7 rounded-full hover:bg-stone-100 flex items-center justify-center text-stone-700"
            title="Previous Period"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => setPeriodOffset(0)}
            className="px-2 text-xs font-semibold text-stone-600 hover:text-stone-900"
          >
            Today
          </button>
          <button
            onClick={() => setPeriodOffset((prev) => Math.min(0, prev + 1))}
            disabled={periodOffset >= 0}
            className="w-7 h-7 rounded-full hover:bg-stone-100 disabled:opacity-30 flex items-center justify-center text-stone-700"
            title="Next Period"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-4 space-y-4 max-w-md mx-auto w-full">
        {/* Time Filter Segmented Tabs */}
        <div className="flex items-center gap-1 p-1 bg-stone-200/70 rounded-2xl">
          {(['weekly', 'monthly', 'yearly'] as TimeFilter[]).map((tab) => (
            <button
              key={tab}
              onClick={() => {
                setFilter(tab);
                setPeriodOffset(0);
                setActiveTooltip(null);
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all font-hindi ${
                filter === tab
                  ? 'bg-orange-500 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {tab === 'weekly' && t.weekly}
              {tab === 'monthly' && t.monthly}
              {tab === 'yearly' && t.yearly}
            </button>
          ))}
        </div>

        {/* Period Summary Card */}
        <div className="bg-white rounded-3xl p-5 border border-amber-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-3 pb-3 border-b border-stone-100">
            <div>
              <span className="text-xs font-bold text-orange-600 uppercase tracking-wider font-sans">
                {dateRangeLabel}
              </span>
              <div className="text-xs text-stone-400 mt-0.5 font-hindi">
                {t.currentMantra}: {selectedMantra}
              </div>
            </div>

            <select
              value={activeMantraFilter}
              onChange={(e) => setActiveMantraFilter(e.target.value)}
              className="text-xs font-semibold bg-stone-50 border border-stone-200 rounded-lg px-2 py-1 text-stone-700 focus:outline-none"
            >
              <option value="ALL">All Mantras</option>
              {predefinedMantras.map((m) => (
                <option key={m.id} value={m.name}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-stone-500 font-hindi">
                {t.totalChants}
              </div>
              <div className="text-2xl font-extrabold text-stone-900 tabular-nums">
                {periodTotal.toLocaleString()}
              </div>
            </div>

            <div>
              <div className="text-xs text-stone-500 font-hindi">
                {t.dailyAverage}
              </div>
              <div className="text-2xl font-extrabold text-orange-600 tabular-nums">
                {dailyAverage.toLocaleString()}
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Vertical Bar Chart */}
        <div className="bg-white rounded-3xl p-5 border border-amber-200/80 shadow-xs flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold text-stone-500 uppercase tracking-wider font-sans">
              Chanting Activity
            </h3>
            {activeTooltip && (
              <span className="text-xs font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded-md border border-orange-200">
                {activeTooltip.label}: {activeTooltip.count} chants
              </span>
            )}
          </div>

          {/* Bar Chart Container */}
          <div className="h-44 flex items-end justify-between gap-1 pt-6 pb-2 border-b border-stone-100">
            {barData.map((d, index) => {
              const heightPercent = maxBarValue > 0 ? Math.round((d.count / maxBarValue) * 100) : 0;
              const hasChanted = d.count > 0;

              return (
                <div
                  key={index}
                  onClick={() => setActiveTooltip({ label: `${d.label} ${d.subLabel}`, count: d.count })}
                  className="flex-1 h-full flex flex-col items-center justify-end cursor-pointer group"
                >
                  {/* Background Track + Filled Bar */}
                  <div className="w-full max-w-[24px] h-full bg-stone-100 rounded-t-lg relative flex flex-col justify-end overflow-hidden group-hover:bg-amber-100/50 transition-colors">
                    <div
                      style={{ height: `${Math.max(heightPercent, hasChanted ? 8 : 0)}%` }}
                      className={`w-full rounded-t-lg transition-all duration-300 ${
                        hasChanted
                          ? 'bg-gradient-to-t from-orange-600 to-amber-400 group-hover:brightness-110'
                          : 'bg-transparent'
                      }`}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* X-Axis Labels */}
          <div className="flex items-center justify-between gap-1 pt-2">
            {barData.map((d, idx) => (
              <div key={idx} className="flex-1 text-center">
                <span className="text-[10px] font-bold text-stone-600 block leading-tight">
                  {d.label}
                </span>
                {d.subLabel && (
                  <span className="text-[9px] text-stone-400 block leading-none">
                    {d.subLabel}
                  </span>
                )}
              </div>
            ))}
          </div>

          <div className="text-[11px] text-stone-400 text-center mt-3">
            Tap on any bar to see exact chants on that day
          </div>
        </div>

        {/* Additional Lifetime Statistics */}
        <div className="bg-white rounded-3xl p-5 border border-amber-200/80 shadow-xs space-y-3">
          <h3 className="text-xs font-bold text-stone-500 uppercase tracking-wider font-sans mb-3">
            {t.progress} - Lifetime Overview
          </h3>

          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100">
              <span className="text-xs text-stone-500 block font-hindi">{t.totalChants}</span>
              <span className="text-lg font-bold text-stone-900 tabular-nums">
                {lifetimeMetrics.totalJaap.toLocaleString()}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100">
              <span className="text-xs text-stone-500 block font-hindi">{t.completedMalas}</span>
              <span className="text-lg font-bold text-orange-600 tabular-nums">
                {lifetimeMetrics.totalMalas}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100">
              <span className="text-xs text-stone-500 block font-hindi">{t.currentStreakLabel}</span>
              <span className="text-lg font-bold text-stone-900 tabular-nums">
                {currentStreak} {t.days}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100">
              <span className="text-xs text-stone-500 block font-hindi">{t.bestStreakLabel}</span>
              <span className="text-lg font-bold text-stone-900 tabular-nums">
                {bestStreak} {t.days}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100 col-span-2 flex items-center justify-between">
              <div>
                <span className="text-xs text-stone-500 block font-hindi">{t.mostActiveDay}</span>
                <span className="text-sm font-bold text-stone-900">
                  {lifetimeMetrics.mostActiveDayStr}
                </span>
              </div>
              <div className="text-right">
                <span className="text-base font-extrabold text-orange-600 tabular-nums">
                  {lifetimeMetrics.mostActiveCount}
                </span>
                <span className="text-xs text-stone-400 block">{t.chants}</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100">
              <span className="text-xs text-stone-500 block font-hindi">{t.totalDaysOfJaap}</span>
              <span className="text-lg font-bold text-stone-900 tabular-nums">
                {lifetimeMetrics.totalDays}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100">
              <span className="text-xs text-stone-500 block font-hindi">{t.dailyAverage}</span>
              <span className="text-lg font-bold text-stone-900 tabular-nums">
                {lifetimeMetrics.avgDaily}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
