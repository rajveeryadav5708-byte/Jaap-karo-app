import React from 'react';
import { AppLanguage, DailyThought } from '../types';
import { translations } from '../data/translations';

interface TodayThoughtCardProps {
  thought: DailyThought;
  currentLang: AppLanguage;
}

export const TodayThoughtCard: React.FC<TodayThoughtCardProps> = ({
  thought,
  currentLang
}) => {
  const t = translations[currentLang] || translations.hi;

  // Use Hindi thought by default or English if English is selected
  const quoteText =
    currentLang === 'en'
      ? thought.quote.en
      : thought.quote.hi;

  const authorName =
    currentLang === 'en'
      ? thought.author.en
      : thought.author.hi;

  return (
    <div className="relative overflow-hidden rounded-2xl bg-white p-4 shadow-xs border border-amber-200/70">
      {/* Decorative orange quotation mark */}
      <div
        className="absolute top-1 right-3 text-6xl font-serif text-orange-200/60 select-none pointer-events-none leading-none"
        aria-hidden="true"
      >
        “
      </div>

      <div className="relative z-10">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="text-[11px] font-bold tracking-wider uppercase text-orange-600 font-sans">
            {t.todayThought}
          </span>
          {thought.source && (
            <span className="text-[11px] text-stone-400">
              · {thought.source}
            </span>
          )}
        </div>

        <p className="text-sm font-medium text-stone-800 leading-relaxed font-hindi italic mb-2">
          "{quoteText}"
        </p>

        <div className="text-right">
          <span className="text-xs font-semibold text-stone-600 font-hindi">
            — {authorName}
          </span>
        </div>
      </div>
    </div>
  );
};
