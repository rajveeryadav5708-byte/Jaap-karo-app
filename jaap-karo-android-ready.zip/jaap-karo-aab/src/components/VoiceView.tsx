import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Volume2, Sparkles, ChevronDown, Repeat } from 'lucide-react';
import { AppLanguage, MantraItem } from '../types';
import { predefinedMantras, getMantraDisplay } from '../data/mantras';
import { translations } from '../data/translations';
import { soundEngine } from '../utils/audio';

interface VoiceViewProps {
  currentLang: AppLanguage;
}

export const VoiceView: React.FC<VoiceViewProps> = ({ currentLang }) => {
  const t = translations[currentLang] || translations.hi;

  const [selectedMantraId, setSelectedMantraId] = useState<string>('radha');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [chantSpeed, setChantSpeed] = useState<number>(1.0);
  const [targetRepetitions, setTargetRepetitions] = useState<number | 'continuous'>(108);
  const [completedRepetitions, setCompletedRepetitions] = useState<number>(0);

  const loopTimerRef = useRef<number | null>(null);

  const currentMantra: MantraItem =
    predefinedMantras.find((m) => m.id === selectedMantraId) || predefinedMantras[0];

  // Stop audio on unmount or mantra change
  useEffect(() => {
    return () => {
      soundEngine.stopSpeech();
      if (loopTimerRef.current) clearInterval(loopTimerRef.current);
    };
  }, [selectedMantraId]);

  const speakChant = () => {
    soundEngine.playBell(1.0);
    soundEngine.speakText(currentMantra.pronunciation, 'hi-IN', chantSpeed);
  };

  const handlePlayToggle = () => {
    if (isPlaying) {
      soundEngine.stopSpeech();
      if (loopTimerRef.current) clearInterval(loopTimerRef.current);
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      speakChant();
      setCompletedRepetitions((prev) => prev + 1);

      // Repeat interval calculation: base 2.2 seconds / chantSpeed
      const intervalMs = Math.round(2200 / chantSpeed);

      loopTimerRef.current = window.setInterval(() => {
        setCompletedRepetitions((prev) => {
          if (targetRepetitions !== 'continuous' && prev >= targetRepetitions) {
            if (loopTimerRef.current) clearInterval(loopTimerRef.current);
            setIsPlaying(false);
            soundEngine.stopSpeech();
            return prev;
          }
          speakChant();
          return prev + 1;
        });
      }, intervalMs);
    }
  };

  const handleReset = () => {
    soundEngine.stopSpeech();
    if (loopTimerRef.current) clearInterval(loopTimerRef.current);
    setIsPlaying(false);
    setCompletedRepetitions(0);
  };

  return (
    <div className="w-full min-h-screen bg-[#FFFBF0] flex flex-col pb-24">
      {/* Top Header */}
      <div className="sticky top-0 z-20 bg-[#FFFBF0]/95 backdrop-blur-md px-4 py-3 border-b border-amber-200/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Volume2 className="w-5 h-5 text-orange-600" />
          <h2 className="text-lg font-bold text-stone-900 font-hindi">
            {t.voiceChanting}
          </h2>
        </div>
      </div>

      <div className="p-4 space-y-4 max-w-md mx-auto w-full flex-1 flex flex-col justify-between">
        {/* Mantra Selector Dropdown Card */}
        <div className="bg-white rounded-3xl p-4 border border-amber-200/80 shadow-xs">
          <label className="text-xs font-bold text-stone-500 uppercase tracking-wider block mb-2 font-sans">
            {t.selectMantraToListen}
          </label>

          <div className="relative">
            <select
              value={selectedMantraId}
              onChange={(e) => {
                handleReset();
                setSelectedMantraId(e.target.value);
              }}
              className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 text-sm font-bold text-stone-800 appearance-none focus:outline-none focus:ring-2 focus:ring-orange-500/30 font-hindi"
            >
              {predefinedMantras.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.devanagari} ({m.name}) - {m.deity}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-stone-400 absolute right-4 top-4 pointer-events-none" />
          </div>
        </div>

        {/* Meditative Visualizer Centerpiece */}
        <div className="relative my-4 flex flex-col items-center justify-center">
          {/* Animated Ambient Rings */}
          <div
            className={`w-64 h-64 rounded-full border border-orange-200/60 flex items-center justify-center transition-all duration-700 ${
              isPlaying ? 'scale-105 sacred-pulse' : 'scale-100'
            }`}
          >
            <div
              className={`w-52 h-52 rounded-full border border-amber-300/80 flex items-center justify-center transition-all duration-500 ${
                isPlaying ? 'scale-105' : 'scale-100'
              }`}
            >
              <div className="w-40 h-40 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 shadow-xl shadow-orange-500/25 flex flex-col items-center justify-center text-white text-center p-3 relative overflow-hidden">
                {/* Subtle spinning rays */}
                <div className="absolute inset-0 bg-radial from-white/20 to-transparent pointer-events-none" />

                <span className="text-2xl font-bold font-devotional drop-shadow-md">
                  {currentMantra.devanagari}
                </span>
                <span className="text-[11px] font-semibold text-amber-100 tracking-wider uppercase mt-1">
                  {currentMantra.english}
                </span>

                {/* Counter inside circle */}
                <div className="mt-2 text-xs font-bold bg-white/20 px-2.5 py-0.5 rounded-full tabular-nums">
                  {completedRepetitions}{' '}
                  {targetRepetitions !== 'continuous' && `/ ${targetRepetitions}`}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Meaning & Deity Card */}
        <div className="bg-white rounded-3xl p-4 border border-amber-200/80 shadow-xs">
          <div className="flex items-center gap-1.5 text-xs font-bold text-orange-600 uppercase tracking-wider mb-1 font-sans">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{currentMantra.deity}</span>
          </div>
          <p className="text-xs text-stone-600 leading-relaxed font-hindi">
            {currentMantra.meaning}
          </p>
        </div>

        {/* Chanting Repetitions & Speed Controls */}
        <div className="bg-white rounded-3xl p-4 border border-amber-200/80 shadow-xs space-y-3">
          {/* Loop Count Segmented Selector */}
          <div>
            <div className="flex items-center justify-between text-xs font-bold text-stone-500 uppercase tracking-wider mb-2 font-sans">
              <span className="flex items-center gap-1">
                <Repeat className="w-3.5 h-3.5" />
                <span>{t.loopCount}</span>
              </span>
              <span className="text-orange-600">
                {targetRepetitions === 'continuous' ? t.continuous : `${targetRepetitions} Chants`}
              </span>
            </div>

            <div className="grid grid-cols-5 gap-1.5">
              {[11, 21, 54, 108, 'continuous'].map((opt) => (
                <button
                  key={String(opt)}
                  onClick={() => setTargetRepetitions(opt as number | 'continuous')}
                  className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                    targetRepetitions === opt
                      ? 'border-orange-500 bg-orange-50 text-orange-950 font-extrabold shadow-xs'
                      : 'border-stone-200 bg-stone-50 text-stone-600 hover:border-amber-300'
                  }`}
                >
                  {opt === 'continuous' ? '∞' : opt}
                </button>
              ))}
            </div>
          </div>

          {/* Speed Controls */}
          <div>
            <div className="flex items-center justify-between text-xs font-bold text-stone-500 uppercase tracking-wider mb-1 font-sans">
              <span>{t.speed}</span>
              <span className="text-orange-600">{chantSpeed}x</span>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {[0.75, 1.0, 1.25, 1.5].map((spd) => (
                <button
                  key={spd}
                  onClick={() => setChantSpeed(spd)}
                  className={`py-1.5 text-xs font-bold rounded-xl border transition-all ${
                    chantSpeed === spd
                      ? 'border-orange-500 bg-orange-50 text-orange-950 font-extrabold'
                      : 'border-stone-200 bg-stone-50 text-stone-600'
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Big Play / Pause and Reset Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={handlePlayToggle}
            className={`flex-1 h-14 rounded-2xl font-bold text-base shadow-md active:scale-[0.98] transition-all flex items-center justify-center gap-2 ${
              isPlaying
                ? 'bg-amber-600 text-white shadow-amber-600/20'
                : 'bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-orange-500/20'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-5 h-5 fill-white" />
                <span>{t.pauseMantra}</span>
              </>
            ) : (
              <>
                <Play className="w-5 h-5 fill-white" />
                <span>{t.playMantra}</span>
              </>
            )}
          </button>

          <button
            onClick={handleReset}
            className="w-14 h-14 rounded-2xl bg-white border border-stone-200 hover:border-amber-300 text-stone-700 flex items-center justify-center active:scale-95 transition-all shadow-xs"
            title="Reset Counter"
          >
            <RotateCcw className="w-5 h-5 text-stone-500" />
          </button>
        </div>
      </div>
    </div>
  );
};
