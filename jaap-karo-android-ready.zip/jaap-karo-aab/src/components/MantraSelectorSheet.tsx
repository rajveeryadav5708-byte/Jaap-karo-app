import React, { useState } from 'react';
import { Pencil, X, Plus, Check } from 'lucide-react';
import { AppLanguage } from '../types';
import { predefinedMantras, getMantraDisplay } from '../data/mantras';
import { translations } from '../data/translations';

interface MantraSelectorSheetProps {
  selectedMantra: string;
  customMantras: string[];
  currentLang: AppLanguage;
  onSelectMantra: (mantra: string) => void;
  onAddCustomMantra: (mantra: string) => void;
}

export const MantraSelectorSheet: React.FC<MantraSelectorSheetProps> = ({
  selectedMantra,
  customMantras,
  currentLang,
  onSelectMantra,
  onAddCustomMantra
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [newMantraInput, setNewMantraInput] = useState('');
  const t = translations[currentLang] || translations.hi;

  const currentInfo = getMantraDisplay(selectedMantra);

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newMantraInput.trim();
    if (trimmed) {
      onAddCustomMantra(trimmed);
      onSelectMantra(trimmed);
      setNewMantraInput('');
      setIsOpen(false);
    }
  };

  return (
    <>
      {/* Mantra Banner Card on Home Screen */}
      <button
        onClick={() => setIsOpen(true)}
        className="w-full text-left bg-gradient-to-r from-amber-50 to-orange-50/80 rounded-2xl p-4 border border-amber-200 shadow-xs flex items-center justify-between active:scale-[0.99] transition-transform"
      >
        <div>
          <div className="text-[11px] font-bold text-orange-600 uppercase tracking-wider mb-0.5">
            {t.selectGodsName}
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-xl font-bold text-stone-900 font-hindi tracking-wide">
              {currentInfo.devanagari}
            </span>
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              ({currentInfo.name})
            </span>
          </div>
          <div className="text-xs text-stone-500 mt-0.5 font-hindi">
            {currentInfo.deity}
          </div>
        </div>

        <div className="w-10 h-10 rounded-xl bg-white border border-amber-300 text-orange-600 flex items-center justify-center shadow-xs">
          <Pencil className="w-4 h-4" />
        </div>
      </button>

      {/* Bottom Sheet Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-stone-950/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div
            className="w-full max-w-lg bg-[#FFFDF7] rounded-t-3xl sm:rounded-3xl max-h-[85vh] flex flex-col shadow-2xl border border-amber-200/90 animate-in slide-in-from-bottom duration-250"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Sheet Header */}
            <div className="p-4 border-b border-amber-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center font-bold text-sm">
                  ॐ
                </div>
                <h3 className="font-bold text-stone-900 text-base font-hindi">
                  {t.selectGodsName}
                </h3>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Mantra List */}
            <div className="p-4 overflow-y-auto space-y-4 max-h-[60vh] no-scrollbar">
              {/* Predefined Mantras Grid */}
              <div className="grid grid-cols-2 gap-2">
                {predefinedMantras.map((mantra) => {
                  const isSelected =
                    selectedMantra.toUpperCase() === mantra.name.toUpperCase();
                  return (
                    <button
                      key={mantra.id}
                      onClick={() => {
                        onSelectMantra(mantra.name);
                        setIsOpen(false);
                      }}
                      className={`p-3 rounded-xl text-left border transition-all flex flex-col justify-between ${
                        isSelected
                          ? 'border-orange-500 bg-orange-50 text-orange-950 font-bold shadow-xs ring-1 ring-orange-500/40'
                          : 'border-stone-200 bg-white hover:border-amber-300 text-stone-800'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <span className="text-base font-bold font-hindi">
                          {mantra.devanagari}
                        </span>
                        {isSelected && (
                          <span className="w-4 h-4 rounded-full bg-orange-500 text-white flex items-center justify-center text-[10px]">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-stone-500 font-medium uppercase tracking-wider mt-1">
                        {mantra.english}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Custom Mantras (if any) */}
              {customMantras.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-stone-500 uppercase tracking-wider mb-2 font-sans">
                    {t.customMantra}
                  </h4>
                  <div className="grid grid-cols-2 gap-2">
                    {customMantras.map((m, idx) => {
                      const isSelected = selectedMantra === m;
                      return (
                        <button
                          key={idx}
                          onClick={() => {
                            onSelectMantra(m);
                            setIsOpen(false);
                          }}
                          className={`p-3 rounded-xl text-left border flex items-center justify-between ${
                            isSelected
                              ? 'border-orange-500 bg-orange-50 text-orange-950 font-bold'
                              : 'border-stone-200 bg-white hover:border-amber-300'
                          }`}
                        >
                          <span className="font-bold text-sm font-hindi truncate">
                            {m}
                          </span>
                          {isSelected && <Check className="w-4 h-4 text-orange-600" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Add Custom Mantra Form */}
              <div className="bg-amber-50/70 rounded-2xl p-3 border border-amber-200/80">
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2 font-sans">
                  {t.customMantra}
                </label>
                <form onSubmit={handleAddCustom} className="flex gap-2">
                  <input
                    type="text"
                    value={newMantraInput}
                    onChange={(e) => setNewMantraInput(e.target.value)}
                    placeholder={t.enterCustomMantra}
                    className="flex-1 bg-white border border-stone-300 rounded-xl px-3 py-2 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-orange-500/40"
                  />
                  <button
                    type="submit"
                    disabled={!newMantraInput.trim()}
                    className="px-4 py-2 bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-xs"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{t.addMantra}</span>
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
