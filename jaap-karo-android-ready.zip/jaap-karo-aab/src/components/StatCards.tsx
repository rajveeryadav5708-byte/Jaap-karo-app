import React from 'react';
import { AppLanguage } from '../types';
import { translations } from '../data/translations';

interface StatCardsProps {
  todayChants: number;
  todayMalas: number;
  malaGoal: number;
  lifetimeChants: number;
  currentLang: AppLanguage;
}

export const StatCards: React.FC<StatCardsProps> = ({
  todayChants,
  todayMalas,
  malaGoal,
  lifetimeChants,
  currentLang
}) => {
  const t = translations[currentLang] || translations.hi;

  return (
    <div className="grid grid-cols-3 gap-2.5">
      {/* 1. JAAP - Today's Chants */}
      <div className="bg-white rounded-2xl p-3 border border-amber-200/70 shadow-xs text-center flex flex-col justify-between">
        <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">
          {t.jaap}
        </span>
        <div className="text-xl font-bold text-stone-900 tabular-nums py-1">
          {todayChants.toLocaleString()}
        </div>
        <span className="text-[10px] text-stone-400">
          {t.chants}
        </span>
      </div>

      {/* 2. MALA - Completed Malas out of Goal */}
      <div className="bg-white rounded-2xl p-3 border border-amber-200/70 shadow-xs text-center flex flex-col justify-between">
        <span className="text-[11px] font-bold text-orange-600 uppercase tracking-wider">
          {t.mala}
        </span>
        <div className="text-xl font-bold text-orange-600 tabular-nums py-1">
          {todayMalas} <span className="text-xs font-normal text-stone-400">/ {malaGoal}</span>
        </div>
        <span className="text-[10px] text-stone-400">
          {t.completedMalas}
        </span>
      </div>

      {/* 3. TOTAL - Lifetime Chants */}
      <div className="bg-white rounded-2xl p-3 border border-amber-200/70 shadow-xs text-center flex flex-col justify-between">
        <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">
          {t.total}
        </span>
        <div className="text-xl font-bold text-stone-900 tabular-nums py-1">
          {lifetimeChants.toLocaleString()}
        </div>
        <span className="text-[10px] text-stone-400">
          {t.total} {t.chants}
        </span>
      </div>
    </div>
  );
};
