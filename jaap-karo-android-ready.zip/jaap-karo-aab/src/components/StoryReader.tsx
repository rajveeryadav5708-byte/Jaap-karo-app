import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Heart,
  Play,
  Pause,
  Square,
  SkipBack,
  SkipForward,
  Type,
  ChevronLeft,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { Story, AppLanguage } from '../types';
import { translations } from '../data/translations';
import { soundEngine } from '../utils/audio';

interface StoryReaderProps {
  story: Story;
  allStories: Story[];
  storyLanguage: 'hi' | 'en';
  isFavorite: boolean;
  appLanguage: AppLanguage;
  onBack: () => void;
  onToggleFavorite: (storyId: string) => void;
  onNavigateStory: (story: Story) => void;
}

export const StoryReader: React.FC<StoryReaderProps> = ({
  story,
  allStories,
  storyLanguage,
  isFavorite,
  appLanguage,
  onBack,
  onToggleFavorite,
  onNavigateStory
}) => {
  const t = translations[appLanguage] || translations.hi;

  // Reading settings
  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg' | 'xl'>('base');
  const [currentParagraphIndex, setCurrentParagraphIndex] = useState<number>(0);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [readingSpeed, setReadingSpeed] = useState<number>(1.0);

  // Content paragraphs based on selected story language
  const paragraphs = storyLanguage === 'hi' ? story.content.hi : story.content.en;
  const storyTitle = storyLanguage === 'hi' ? story.title.hi : story.title.en;
  const moralText = storyLanguage === 'hi' ? story.moral.hi : story.moral.en;

  // Navigation: Find current index in list
  const currentIndex = allStories.findIndex((s) => s.id === story.id);
  const prevStory = currentIndex > 0 ? allStories[currentIndex - 1] : null;
  const nextStory = currentIndex < allStories.length - 1 ? allStories[currentIndex + 1] : null;

  // Cleanup speech when unmounting or switching stories
  useEffect(() => {
    return () => {
      soundEngine.stopSpeech();
    };
  }, [story.id]);

  const speakCurrentParagraph = (paraIdx: number) => {
    if (paraIdx < 0 || paraIdx >= paragraphs.length) {
      setIsPlayingAudio(false);
      soundEngine.stopSpeech();
      return;
    }

    soundEngine.stopSpeech();
    const textToSpeak = paragraphs[paraIdx];
    const langCode = storyLanguage === 'hi' ? 'hi-IN' : 'en-US';

    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.lang = langCode;
      utterance.rate = readingSpeed;
      utterance.pitch = 1.0;

      utterance.onend = () => {
        if (paraIdx + 1 < paragraphs.length) {
          setCurrentParagraphIndex(paraIdx + 1);
          speakCurrentParagraph(paraIdx + 1);
        } else {
          setIsPlayingAudio(false);
        }
      };

      utterance.onerror = () => {
        setIsPlayingAudio(false);
      };

      window.speechSynthesis.speak(utterance);
      setIsPlayingAudio(true);
    }
  };

  const handlePlayPause = () => {
    if (isPlayingAudio) {
      soundEngine.stopSpeech();
      setIsPlayingAudio(false);
    } else {
      speakCurrentParagraph(currentParagraphIndex);
    }
  };

  const handleStopAudio = () => {
    soundEngine.stopSpeech();
    setIsPlayingAudio(false);
    setCurrentParagraphIndex(0);
  };

  const handleNextPara = () => {
    if (currentParagraphIndex < paragraphs.length - 1) {
      const nextIdx = currentParagraphIndex + 1;
      setCurrentParagraphIndex(nextIdx);
      if (isPlayingAudio) {
        speakCurrentParagraph(nextIdx);
      }
    }
  };

  const handlePrevPara = () => {
    if (currentParagraphIndex > 0) {
      const prevIdx = currentParagraphIndex - 1;
      setCurrentParagraphIndex(prevIdx);
      if (isPlayingAudio) {
        speakCurrentParagraph(prevIdx);
      }
    }
  };

  // Font size classes
  const fontClass = {
    sm: 'text-sm leading-relaxed',
    base: 'text-base leading-relaxed',
    lg: 'text-lg leading-relaxed',
    xl: 'text-xl leading-relaxed'
  }[fontSize];

  return (
    <div className="w-full min-h-screen bg-[#FFFDF7] flex flex-col pb-28">
      {/* Top Reading Navigation Bar */}
      <div className="sticky top-0 z-30 bg-[#FFFDF7]/95 backdrop-blur-md px-4 py-3 border-b border-amber-200/80 flex items-center justify-between">
        <button
          onClick={() => {
            soundEngine.stopSpeech();
            onBack();
          }}
          className="w-10 h-10 rounded-full bg-white border border-stone-200 flex items-center justify-center text-stone-700 active:scale-95 transition-all shadow-xs"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          {/* Font Size Adjusters */}
          <div className="flex items-center gap-1 bg-stone-100 rounded-xl p-1">
            <button
              onClick={() => setFontSize('sm')}
              className={`px-2 py-1 text-xs font-bold rounded-lg ${fontSize === 'sm' ? 'bg-white shadow-xs' : 'text-stone-500'}`}
            >
              A-
            </button>
            <button
              onClick={() => setFontSize('base')}
              className={`px-2 py-1 text-xs font-bold rounded-lg ${fontSize === 'base' ? 'bg-white shadow-xs' : 'text-stone-500'}`}
            >
              A
            </button>
            <button
              onClick={() => setFontSize('lg')}
              className={`px-2 py-1 text-xs font-bold rounded-lg ${fontSize === 'lg' ? 'bg-white shadow-xs' : 'text-stone-500'}`}
            >
              A+
            </button>
          </div>

          {/* Favorite Toggle */}
          <button
            onClick={() => onToggleFavorite(story.id)}
            className={`w-10 h-10 rounded-full border flex items-center justify-center active:scale-95 transition-all ${
              isFavorite
                ? 'bg-red-50 border-red-200 text-red-500'
                : 'bg-white border-stone-200 text-stone-400 hover:text-stone-700'
            }`}
          >
            <Heart className={`w-5 h-5 ${isFavorite ? 'fill-red-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Story Content Container */}
      <div className="p-4 sm:p-6 max-w-2xl mx-auto w-full space-y-5">
        {/* Deity & Category Metadata */}
        <div className="flex items-center gap-2 text-xs text-orange-600 font-bold uppercase tracking-wider font-sans">
          <span>{story.deity}</span>
          <span>·</span>
          <span>{story.category}</span>
          <span>·</span>
          <span className="text-stone-400">{story.readTimeMinutes} min read</span>
        </div>

        {/* Story Title */}
        <h1 className="text-2xl sm:text-3xl font-extrabold text-stone-900 leading-tight font-devotional">
          {storyTitle}
        </h1>

        {/* Audio Auto Reader Toolbar */}
        <div className="bg-gradient-to-r from-amber-50 to-orange-50/80 rounded-2xl p-3 border border-amber-200 flex flex-wrap items-center justify-between gap-2 shadow-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePlayPause}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all ${
                isPlayingAudio
                  ? 'bg-amber-600 text-white'
                  : 'bg-orange-500 hover:bg-orange-600 text-white'
              }`}
            >
              {isPlayingAudio ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
              <span>{isPlayingAudio ? t.pause : t.listenStory}</span>
            </button>

            <button
              onClick={handleStopAudio}
              disabled={!isPlayingAudio && currentParagraphIndex === 0}
              className="p-2 rounded-xl bg-white border border-stone-200 text-stone-600 hover:bg-stone-50 disabled:opacity-40"
              title={t.stopAudio}
            >
              <Square className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Paragraph step & Speed controls */}
          <div className="flex items-center gap-1 text-xs">
            <button
              onClick={handlePrevPara}
              disabled={currentParagraphIndex === 0}
              className="p-1.5 rounded-lg bg-white border border-stone-200 text-stone-600 disabled:opacity-40"
              title="Previous Paragraph"
            >
              <SkipBack className="w-3.5 h-3.5" />
            </button>
            <span className="px-2 text-[11px] font-bold text-stone-500 tabular-nums">
              {currentParagraphIndex + 1}/{paragraphs.length}
            </span>
            <button
              onClick={handleNextPara}
              disabled={currentParagraphIndex >= paragraphs.length - 1}
              className="p-1.5 rounded-lg bg-white border border-stone-200 text-stone-600 disabled:opacity-40"
              title="Next Paragraph"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>

            {/* Speed Switcher */}
            <select
              value={readingSpeed}
              onChange={(e) => setReadingSpeed(parseFloat(e.target.value))}
              className="ml-1 text-[11px] font-bold bg-white border border-stone-200 rounded-lg px-1.5 py-1 text-stone-700"
            >
              <option value={0.75}>0.75x</option>
              <option value={1.0}>1.0x</option>
              <option value={1.25}>1.25x</option>
              <option value={1.5}>1.5x</option>
            </select>
          </div>
        </div>

        {/* Story Paragraphs */}
        <div className="space-y-4 pt-2">
          {paragraphs.map((p, idx) => {
            const isCurrentlyReading = isPlayingAudio && currentParagraphIndex === idx;
            return (
              <p
                key={idx}
                onClick={() => {
                  setCurrentParagraphIndex(idx);
                  if (isPlayingAudio) {
                    speakCurrentParagraph(idx);
                  }
                }}
                className={`p-3 rounded-2xl transition-all cursor-pointer font-hindi ${fontClass} ${
                  isCurrentlyReading
                    ? 'bg-amber-100/90 text-stone-900 border-l-4 border-orange-500 shadow-xs'
                    : 'text-stone-800 hover:bg-stone-50'
                }`}
              >
                {p}
              </p>
            );
          })}
        </div>

        {/* Moral / Teaching Card */}
        <div className="mt-6 rounded-2xl bg-amber-50/70 border border-amber-200 p-4">
          <div className="flex items-center gap-1.5 text-xs font-bold text-orange-600 uppercase tracking-wider mb-1 font-sans">
            <Sparkles className="w-4 h-4" />
            <span>शिक्षा / Moral</span>
          </div>
          <p className="text-sm font-semibold text-stone-800 font-hindi italic">
            "{moralText}"
          </p>
        </div>

        {/* Previous / Next Story Navigation */}
        <div className="pt-6 border-t border-amber-200 flex items-center justify-between gap-3">
          {prevStory ? (
            <button
              onClick={() => onNavigateStory(prevStory)}
              className="flex-1 p-3 rounded-2xl bg-white border border-stone-200 hover:border-amber-300 text-left flex items-center gap-2 shadow-xs active:scale-[0.98] transition-all"
            >
              <ChevronLeft className="w-5 h-5 text-orange-500 shrink-0" />
              <div className="truncate">
                <span className="text-[10px] text-stone-400 block uppercase font-bold">
                  {t.previousStory}
                </span>
                <span className="text-xs font-bold text-stone-800 truncate block font-hindi">
                  {storyLanguage === 'hi' ? prevStory.title.hi : prevStory.title.en}
                </span>
              </div>
            </button>
          ) : (
            <div className="flex-1" />
          )}

          {nextStory && (
            <button
              onClick={() => onNavigateStory(nextStory)}
              className="flex-1 p-3 rounded-2xl bg-white border border-stone-200 hover:border-amber-300 text-right flex items-center justify-end gap-2 shadow-xs active:scale-[0.98] transition-all"
            >
              <div className="truncate">
                <span className="text-[10px] text-stone-400 block uppercase font-bold">
                  {t.nextStory}
                </span>
                <span className="text-xs font-bold text-stone-800 truncate block font-hindi">
                  {storyLanguage === 'hi' ? nextStory.title.hi : nextStory.title.en}
                </span>
              </div>
              <ChevronRight className="w-5 h-5 text-orange-500 shrink-0" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
