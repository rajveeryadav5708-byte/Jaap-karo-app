import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { Pencil, Play, Pause, RotateCcw, Trophy, Sparkles, X, Heart } from 'lucide-react';
import { AppLanguage } from '../types';
import { translations } from '../data/translations';
import { predefinedMantras, getMantraDisplay } from '../data/mantras';
import { soundEngine } from '../utils/audio';
import { loadGameHighScore, saveGameHighScore } from '../utils/storage';

interface DevotionalGameViewProps {
  currentLang: AppLanguage;
  hapticsEnabled: boolean;
}

interface Balloon {
  id: number;
  x: number; // percentage 5% to 85%
  y: number; // percentage 110% (bottom) to -20% (top)
  speed: number;
  color: string;
  size: number; // in px
  text: string;
  isPopped?: boolean;
}

const BALLOON_COLORS = [
  '#F39812', // Saffron
  '#E65100', // Deep Orange
  '#FFB300', // Amber
  '#D81B60', // Rose/Crimson
  '#7B1FA2', // Royal Purple
  '#0288D1', // Sacred Blue
  '#2E7D32'  // Tulsi Green
];

export const DevotionalGameView: React.FC<DevotionalGameViewProps> = ({
  currentLang,
  hapticsEnabled
}) => {
  const t = translations[currentLang] || translations.hi;

  // Selected Mantra for balloons
  const [selectedGodName, setSelectedGodName] = useState<string>('RADHA');
  const [isSelectorOpen, setIsSelectorOpen] = useState<boolean>(false);
  const [customInput, setCustomInput] = useState<string>('');

  // Game state
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => loadGameHighScore());
  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [balloons, setBalloons] = useState<Balloon[]>([]);

  const gameLoopRef = useRef<number | null>(null);
  const spawnTimerRef = useRef<number | null>(null);
  const nextIdRef = useRef<number>(1);

  const displayInfo = getMantraDisplay(selectedGodName);

  // Spawn new balloon
  const spawnBalloon = () => {
    const newBalloon: Balloon = {
      id: nextIdRef.current++,
      x: 5 + Math.random() * 80, // 5% to 85% horizontal
      y: 105, // start just below viewport
      speed: 0.35 + Math.random() * 0.45 + (60 - timeLeft) * 0.005, // slight speed ramp
      color: BALLOON_COLORS[Math.floor(Math.random() * BALLOON_COLORS.length)],
      size: 64 + Math.random() * 20,
      text: displayInfo.devanagari
    };
    setBalloons((prev) => [...prev.slice(-15), newBalloon]);
  };

  // Start or resume game
  const startGame = () => {
    if (isGameOver) {
      setScore(0);
      setTimeLeft(60);
      setIsGameOver(false);
      setBalloons([]);
    }
    setIsPlaying(true);
  };

  const pauseGame = () => {
    setIsPlaying(false);
  };

  const restartGame = () => {
    setIsPlaying(false);
    setScore(0);
    setTimeLeft(60);
    setIsGameOver(false);
    setBalloons([]);
  };

  // Main game tick: moves balloons upward
  useEffect(() => {
    if (!isPlaying) {
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
      return;
    }

    const tick = () => {
      setBalloons((prev) =>
        prev
          .map((b) => ({
            ...b,
            y: b.y - b.speed
          }))
          .filter((b) => b.y > -25) // remove when floated out of screen
      );
      gameLoopRef.current = requestAnimationFrame(tick);
    };

    gameLoopRef.current = requestAnimationFrame(tick);
    return () => {
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    };
  }, [isPlaying]);

  // Balloon Spawner timer
  useEffect(() => {
    if (!isPlaying) {
      if (spawnTimerRef.current) clearInterval(spawnTimerRef.current);
      return;
    }

    // Spawn every 900ms
    spawnTimerRef.current = window.setInterval(() => {
      spawnBalloon();
    }, 900);

    return () => {
      if (spawnTimerRef.current) clearInterval(spawnTimerRef.current);
    };
  }, [isPlaying, displayInfo.devanagari, timeLeft]);

  // Countdown timer
  useEffect(() => {
    if (!isPlaying || isGameOver) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsPlaying(false);
          setIsGameOver(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isPlaying, isGameOver]);

  // Handle Game Over highscore check
  useEffect(() => {
    if (isGameOver) {
      if (score > highScore) {
        setHighScore(score);
        saveGameHighScore(score);
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      }
    }
  }, [isGameOver, score, highScore]);

  // Pop balloon tap handler
  const handlePopBalloon = (id: number) => {
    if (!isPlaying) return;

    // Pop sound & vibration
    soundEngine.playPop();
    soundEngine.triggerHaptic(20, hapticsEnabled);

    setBalloons((prev) => prev.filter((b) => b.id !== id));
    setScore((prev) => prev + 1);
  };

  const handleSelectName = (name: string) => {
    setSelectedGodName(name);
    setIsSelectorOpen(false);
  };

  const handleAddCustomName = (e: React.FormEvent) => {
    e.preventDefault();
    if (customInput.trim()) {
      setSelectedGodName(customInput.trim());
      setCustomInput('');
      setIsSelectorOpen(false);
    }
  };

  return (
    <div className="w-full min-h-screen bg-[#FFFBF0] flex flex-col pb-24 overflow-hidden select-none">
      {/* Top Header / Score Bar */}
      <div className="sticky top-0 z-30 bg-[#FFFBF0]/95 backdrop-blur-md px-4 py-3 border-b border-amber-200/80 flex items-center justify-between">
        {/* Name Selector Trigger at top-left */}
        <button
          onClick={() => setIsSelectorOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-amber-200 text-stone-800 text-xs font-bold hover:border-orange-400 active:scale-95 transition-all shadow-xs"
        >
          <Pencil className="w-3.5 h-3.5 text-orange-500" />
          <span className="font-hindi">{displayInfo.devanagari}</span>
        </button>

        {/* Score & Timer Indicators */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 text-xs font-bold text-stone-700 bg-white border border-amber-200 px-2.5 py-1 rounded-full shadow-xs">
            <span className="text-[10px] text-stone-400 uppercase">Time</span>
            <span className="tabular-nums text-orange-600 font-extrabold">{timeLeft}s</span>
          </div>

          <div className="flex items-center gap-1 text-xs font-bold text-stone-700 bg-white border border-amber-200 px-2.5 py-1 rounded-full shadow-xs">
            <span className="text-[10px] text-stone-400 uppercase">{t.score}</span>
            <span className="tabular-nums text-stone-900 font-extrabold">{score}</span>
          </div>

          <div className="flex items-center gap-1 text-xs font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-1 rounded-full">
            <Trophy className="w-3 h-3 text-amber-500" />
            <span className="tabular-nums font-extrabold">{highScore}</span>
          </div>
        </div>
      </div>

      {/* Main Game Stage */}
      <div className="relative flex-1 w-full max-w-md mx-auto min-h-[460px] overflow-hidden bg-gradient-to-b from-[#FFFDF8] to-[#FFF7E8] border-x border-amber-100 flex flex-col justify-between p-4">
        {/* Sky / Floating Cloud Backdrop */}
        <div className="absolute inset-0 pointer-events-none opacity-40">
          <div className="absolute top-8 left-6 w-24 h-10 rounded-full bg-amber-200/50 blur-md" />
          <div className="absolute top-28 right-8 w-32 h-12 rounded-full bg-orange-200/40 blur-md" />
          <div className="absolute top-64 left-16 w-28 h-10 rounded-full bg-amber-100/60 blur-md" />
        </div>

        {/* Floating Balloons Canvas */}
        <div className="absolute inset-0 overflow-hidden">
          {balloons.map((b) => (
            <div
              key={b.id}
              onClick={() => handlePopBalloon(b.id)}
              style={{
                left: `${b.x}%`,
                top: `${b.y}%`,
                width: `${b.size}px`,
                height: `${b.size * 1.25}px`
              }}
              className="absolute -translate-x-1/2 cursor-pointer flex flex-col items-center justify-center transition-transform active:scale-125"
            >
              {/* Balloon Bubble */}
              <div
                style={{ backgroundColor: b.color }}
                className="w-full h-full rounded-[50%_50%_50%_50%/40%_40%_60%_60%] shadow-lg shadow-stone-900/10 flex items-center justify-center p-2 text-white font-bold text-center border-t-2 border-white/40 relative overflow-hidden"
              >
                {/* Highlight shine */}
                <div className="absolute top-2 left-2 w-3 h-5 rounded-full bg-white/40 rotate-12" />
                <span className="font-hindi text-xs sm:text-sm font-extrabold drop-shadow-md leading-tight">
                  {b.text}
                </span>
              </div>
              {/* Balloon knot and thread */}
              <div
                style={{ borderTopColor: b.color }}
                className="w-0 h-0 border-x-4 border-x-transparent border-t-6 -mt-0.5"
              />
              <div className="w-0.5 h-6 bg-stone-300" />
            </div>
          ))}
        </div>

        {/* Start / Intro Screen */}
        {!isPlaying && !isGameOver && (
          <div className="relative z-10 my-auto text-center p-6 bg-white/90 backdrop-blur-sm rounded-3xl border border-amber-200 shadow-xl max-w-xs mx-auto">
            <div className="w-14 h-14 rounded-2xl bg-orange-100 text-orange-600 flex items-center justify-center mx-auto mb-3">
              <Sparkles className="w-7 h-7" />
            </div>
            <h3 className="font-bold text-stone-900 text-lg mb-1 font-hindi">
              {t.gameTitle}
            </h3>
            <p className="text-xs text-stone-600 mb-5 leading-relaxed">
              {t.popBalloons}. प्रत्येक गुब्बारे पर प्रभु का पावन नाम अंकित है।
            </p>

            <button
              onClick={startGame}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 text-white font-bold text-sm shadow-md shadow-orange-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>{t.startGame}</span>
            </button>
          </div>
        )}

        {/* Game Over Modal */}
        {isGameOver && (
          <div className="relative z-20 my-auto text-center p-6 bg-white rounded-3xl border border-amber-200 shadow-2xl max-w-xs mx-auto animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto mb-3">
              <Trophy className="w-7 h-7" />
            </div>
            <h3 className="font-bold text-stone-900 text-xl mb-1 font-hindi">
              {t.gameOver}!
            </h3>
            <p className="text-xs text-stone-500 mb-4">
              बहुत सुंदर प्रयास!
            </p>

            <div className="bg-stone-50 rounded-2xl p-3 border border-stone-100 mb-5 flex items-center justify-around">
              <div>
                <span className="text-[11px] text-stone-400 block uppercase font-bold">
                  {t.score}
                </span>
                <span className="text-2xl font-extrabold text-stone-900 tabular-nums">
                  {score}
                </span>
              </div>
              <div className="w-px h-8 bg-stone-200" />
              <div>
                <span className="text-[11px] text-stone-400 block uppercase font-bold">
                  {t.highScore}
                </span>
                <span className="text-2xl font-extrabold text-orange-600 tabular-nums">
                  {highScore}
                </span>
              </div>
            </div>

            <button
              onClick={startGame}
              className="w-full py-3.5 rounded-2xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm shadow-md shadow-orange-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>{t.playAgain}</span>
            </button>
          </div>
        )}

        {/* Bottom Play / Pause / Restart Toolbar */}
        <div className="relative z-10 w-full flex items-center justify-center gap-3 pt-3">
          {isPlaying ? (
            <button
              onClick={pauseGame}
              className="px-5 py-2.5 rounded-2xl bg-white/90 border border-stone-200 hover:border-amber-300 text-stone-700 font-bold text-xs flex items-center gap-1.5 shadow-xs active:scale-95 transition-all"
            >
              <Pause className="w-4 h-4" />
              <span>{t.pause}</span>
            </button>
          ) : (
            !isGameOver && (
              <button
                onClick={startGame}
                className="px-5 py-2.5 rounded-2xl bg-orange-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs active:scale-95 transition-all"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>{t.startGame}</span>
              </button>
            )
          )}

          <button
            onClick={restartGame}
            className="w-10 h-10 rounded-2xl bg-white/90 border border-stone-200 hover:border-amber-300 text-stone-700 flex items-center justify-center shadow-xs active:scale-95 transition-all"
            title="Restart"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Select God's Name Modal */}
      {isSelectorOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-amber-200 max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100 mb-3">
              <h3 className="font-bold text-stone-900 text-sm font-hindi">
                गुब्बारे पर प्रभु का नाम चुनें
              </h3>
              <button
                onClick={() => setIsSelectorOpen(false)}
                className="w-7 h-7 rounded-full bg-stone-100 flex items-center justify-center text-stone-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-y-auto space-y-2 flex-1 no-scrollbar pr-1">
              <div className="grid grid-cols-2 gap-2">
                {predefinedMantras.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => handleSelectName(m.name)}
                    className={`p-2.5 rounded-xl border text-left font-hindi text-sm font-bold transition-all ${
                      selectedGodName.toUpperCase() === m.name.toUpperCase()
                        ? 'border-orange-500 bg-orange-50 text-orange-950 shadow-xs'
                        : 'border-stone-200 hover:border-amber-300 text-stone-800'
                    }`}
                  >
                    {m.devanagari}
                  </button>
                ))}
              </div>

              {/* Custom Input */}
              <form onSubmit={handleAddCustomName} className="pt-2 flex gap-1.5">
                <input
                  type="text"
                  value={customInput}
                  onChange={(e) => setCustomInput(e.target.value)}
                  placeholder="अपना नाम / मंत्र लिखें..."
                  className="flex-1 px-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
                <button
                  type="submit"
                  disabled={!customInput.trim()}
                  className="px-3 py-1.5 bg-orange-500 disabled:opacity-40 text-white font-bold text-xs rounded-xl"
                >
                  OK
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
