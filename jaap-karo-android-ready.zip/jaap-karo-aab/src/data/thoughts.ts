import { DailyThought } from '../types';

export const dailyThoughts: DailyThought[] = [
  {
    id: 1,
    quote: {
      hi: "कलयुग केवल नाम अधारा। सुमिरि सुमिरि नर उतरहिं पारा॥",
      en: "In Kaliyuga, the divine Name is the sole refuge; by constant chanting, man crosses the ocean of life."
    },
    author: {
      hi: "गोस्वामी तुलसीदास",
      en: "Goswami Tulsidas"
    },
    source: "रामचरितमानस"
  },
  {
    id: 2,
    quote: {
      hi: "पोथी पढ़ि पढ़ि जग मुआ, पंडित भया न कोय। ढाई आखर प्रेम का, पढ़े सो पंडित होय॥",
      en: "Reading scriptures the world died, none became truly wise; one who reads two and a half letters of love becomes wise."
    },
    author: {
      hi: "संत कबीर दास",
      en: "Sant Kabir Das"
    },
    source: "कबीर दोहावली"
  },
  {
    id: 3,
    quote: {
      hi: "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन। मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि॥",
      en: "You have a right to perform your prescribed duties, but you are not entitled to the fruits of your actions."
    },
    author: {
      hi: "भगवान श्री कृष्ण",
      en: "Bhagavan Sri Krishna"
    },
    source: "श्रीमद्भगवद्गीता (२.४७)"
  },
  {
    id: 4,
    quote: {
      hi: "राम नाम कल्पतरु कलि कल्याण निवासु। जो सुमिरत भयो भांग तें तुलसी तुलसीदासु॥",
      en: "The holy name of Rama is the wish-fulfilling tree of Kaliyuga; by chanting it, even wild grass turned into sacred Tulsi."
    },
    author: {
      hi: "गोस्वामी तुलसीदास",
      en: "Goswami Tulsidas"
    },
    source: "दोहावली"
  },
  {
    id: 5,
    quote: {
      hi: "उठो, जागो और तब तक मत रुको जब तक कि लक्ष्य की प्राप्ति न हो जाए।",
      en: "Arise, awake, and stop not until the goal is reached."
    },
    author: {
      hi: "स्वामी विवेकानन्द",
      en: "Swami Vivekananda"
    },
    source: "कठोपनिषद् व्याख्या"
  },
  {
    id: 6,
    quote: {
      hi: "हरि अनंत हरि कथा अनंता। कहहिं सुनहिं बहुबिधि सब संता॥",
      en: "Infinite is the Lord and infinite are His glories; saints recount and hear them in manifold ways."
    },
    author: {
      hi: "गोस्वामी तुलसीदास",
      en: "Goswami Tulsidas"
    },
    source: "रामचरितमानस"
  },
  {
    id: 7,
    quote: {
      hi: "मन तू जोत सरूप है, आपना मूल पछाण।",
      en: "O mind, you are the very embodiment of Divine Light; recognize your true divine origin."
    },
    author: {
      hi: "गुरु नानक देव जी",
      en: "Guru Nanak Dev Ji"
    },
    source: "श्री आदि ग्रन्थ"
  },
  {
    id: 8,
    quote: {
      hi: "जाकी रही भावना जैसी, प्रभु मूरति देखी तिन तैसी।",
      en: "According to the purity of one's devotional heart, so does one behold the sacred form of the Lord."
    },
    author: {
      hi: "गोस्वामी तुलसीदास",
      en: "Goswami Tulsidas"
    },
    source: "बालकाण्ड"
  },
  {
    id: 9,
    quote: {
      hi: "सत्यं शिवं सुन्दरम् - जो सत्य है वही शिव है, और जो शिव है वही सुंदर और परम कल्याणकारी है।",
      en: "Truth is Auspiciousness, and Auspiciousness is the highest Divine Beauty."
    },
    author: {
      hi: "ऋषि वाणी",
      en: "Vedic Sages"
    },
    source: "उपनिषद्"
  },
  {
    id: 10,
    quote: {
      hi: "ईश्वर की प्राप्ति का सबसे सरल और श्रेष्ठ मार्ग निरंतर प्रेमपूर्वक नाम स्मरण है।",
      en: "The simplest and highest path to attain the Divine is continuous, loving remembrance of the Holy Name."
    },
    author: {
      hi: "श्री रामकृष्ण परमहंस",
      en: "Sri Ramakrishna Paramahamsa"
    },
    source: "कथामृत"
  },
  {
    id: 11,
    quote: {
      hi: "मेरे तो गिरधर गोपाल, दूसरो न कोई। जाके सिर मोर मुकुट, मेरो पति सोई॥",
      en: "Mine is only the divine cowherd Giridhar Gopal, none other; He who wears the peacock crown is my eternal Lord."
    },
    author: {
      hi: "भक्त शिरोमणि मीराबाई",
      en: "Bhakta Shiromani Meerabai"
    },
    source: "मीरा पदावली"
  },
  {
    id: 12,
    quote: {
      hi: "नाम संकीर्तनं यस्य सर्वपापप्रणाशनम्। प्रणामो दुःखशमनस्तं नमामि हरिं परम्॥",
      en: "Chanting of Whose name destroys all sins, and bowing to Whom quenches all sorrow; unto that Supreme Lord Hari I bow."
    },
    author: {
      hi: "श्रीमद्भागवत महापुराण",
      en: "Srimad Bhagavatam (12.13.23)"
    },
    source: "महापुराण"
  }
];

export function getTodayThought(): DailyThought {
  const now = new Date();
  const dayOfYear = Math.floor(
    (now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24)
  );
  const index = Math.abs(dayOfYear) % dailyThoughts.length;
  return dailyThoughts[index];
}
