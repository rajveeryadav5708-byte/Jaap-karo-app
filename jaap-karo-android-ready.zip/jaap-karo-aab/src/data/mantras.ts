import { MantraItem } from '../types';

export const predefinedMantras: MantraItem[] = [
  {
    id: 'radha',
    name: 'RADHA',
    devanagari: 'राधा',
    english: 'RADHA',
    deity: 'Shri Radha Rani',
    meaning: 'The eternal beloved of Sri Krishna, embodiment of supreme devotion and grace.',
    pronunciation: 'राधा'
  },
  {
    id: 'raadhe',
    name: 'RAADHE',
    devanagari: 'राधे',
    english: 'RAADHE',
    deity: 'Shri Radharani',
    meaning: 'Affectionate invocation to Sri Radha for unconditional surrender and bhakti.',
    pronunciation: 'राधे'
  },
  {
    id: 'ram',
    name: 'RAM',
    devanagari: 'राम',
    english: 'RAM',
    deity: 'Lord Sri Rama',
    meaning: 'Taraka mantra; embodies supreme virtue, righteousness, and truth.',
    pronunciation: 'राम'
  },
  {
    id: 'sita_ram',
    name: 'SITA RAM',
    devanagari: 'सीता राम',
    english: 'SITA RAM',
    deity: 'Mata Sita & Sri Rama',
    meaning: 'The divine union of pure devotion (Sita) and supreme consciousness (Rama).',
    pronunciation: 'सीता राम'
  },
  {
    id: 'mahadev',
    name: 'MAHADEV',
    devanagari: 'महादेव',
    english: 'MAHADEV',
    deity: 'Lord Shiva',
    meaning: 'The Great God of Gods, Lord of compassion, meditation, and liberation.',
    pronunciation: 'महादेव'
  },
  {
    id: 'om_namah_shivay',
    name: 'OM NAMAH SHIVAY',
    devanagari: 'ॐ नमः शिवाय',
    english: 'OM NAMAH SHIVAY',
    deity: 'Lord Shiva',
    meaning: 'The sacred five-syllable Panchakshari mantra harmonizing the 5 universal elements.',
    pronunciation: 'ॐ नमः शिवाय'
  },
  {
    id: 'om_gan_ganapataye',
    name: 'OM GAN GANAPATAYE NAMAH',
    devanagari: 'ॐ गं गणपतये नमः',
    english: 'OM GAN GANAPATAYE NAMAH',
    deity: 'Lord Ganesha',
    meaning: 'Salutations to Lord Ganesha, remover of all obstacles and giver of wisdom.',
    pronunciation: 'ॐ गं गणपतये नमः'
  },
  {
    id: 'hare_krishna',
    name: 'HARE KRISHNA',
    devanagari: 'हरे कृष्णा',
    english: 'HARE KRISHNA',
    deity: 'Sri Radha Krishna',
    meaning: 'The Maha Mantra that awakens deep divine love and spiritual ecstasy.',
    pronunciation: 'हरे कृष्ण'
  },
  {
    id: 'krishna',
    name: 'KRISHNA',
    devanagari: 'कृष्ण',
    english: 'KRISHNA',
    deity: 'Lord Sri Krishna',
    meaning: 'The All-Attractive Supreme Lord, reservoir of infinite joy and compassion.',
    pronunciation: 'कृष्ण'
  },
  {
    id: 'shiva',
    name: 'SHIVA',
    devanagari: 'शिव',
    english: 'SHIVA',
    deity: 'Lord Shiva',
    meaning: 'The Auspicious One, absolute stillness and unbounded transcendent light.',
    pronunciation: 'शिव'
  },
  {
    id: 'hanuman',
    name: 'HANUMAN',
    devanagari: 'हनुमान',
    english: 'HANUMAN',
    deity: 'Sankat Mochan Hanuman',
    meaning: 'Embodiment of valor, humility, unwavering loyalty, and supreme strength.',
    pronunciation: 'हनुमान'
  },
  {
    id: 'durga',
    name: 'DURGA',
    devanagari: 'दुर्गा',
    english: 'DURGA',
    deity: 'Maa Durga',
    meaning: 'The invincible divine Mother who destroys fear, evil, and sorrows.',
    pronunciation: 'दुर्गा'
  },
  {
    id: 'narayan',
    name: 'NARAYAN',
    devanagari: 'नारायण',
    english: 'NARAYAN',
    deity: 'Lord Vishnu / Narayana',
    meaning: 'The eternal sustainer of creation in whom all living beings reside.',
    pronunciation: 'नारायण'
  },
  {
    id: 'soham',
    name: 'SOHAM',
    devanagari: 'सोऽहम्',
    english: 'SOHAM',
    deity: 'Universal Self (Brahman)',
    meaning: 'I am That; the natural sound of life breath echoing our unity with God.',
    pronunciation: 'सोऽहम्'
  }
];

export function getMantraDisplay(mantraNameOrId: string): { name: string; devanagari: string; deity: string } {
  const found = predefinedMantras.find(
    (m) => m.name.toUpperCase() === mantraNameOrId.toUpperCase() || m.id === mantraNameOrId.toLowerCase()
  );
  if (found) {
    return { name: found.name, devanagari: found.devanagari, deity: found.deity };
  }
  return {
    name: mantraNameOrId,
    devanagari: mantraNameOrId,
    deity: "इष्टदेव / Divine"
  };
}
