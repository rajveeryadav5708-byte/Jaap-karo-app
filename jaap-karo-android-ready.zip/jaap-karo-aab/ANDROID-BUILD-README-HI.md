# Jaap Karo – Android AAB build

This project has been prepared for a Capacitor Android wrapper and a GitHub Actions cloud build.

## Important
- Android application ID: `com.hatexgaane.jaapkaro` (keep this unchanged after publishing).
- The current workflow produces a **release AAB build artifact**. It is not yet Play-Store-uploadable until it is signed with a persistent upload key.
- Never share your keystore file or passwords publicly. Keep a secure backup. Do not regenerate the upload key for future updates.

## Build
1. Upload the contents of this folder to a GitHub repository on the `main` branch.
2. Open the repository's **Actions** tab and allow GitHub Actions if prompted.
3. Select **Build Android AAB** and tap **Run workflow** (or push a commit to `main`).
4. Open the completed workflow run and download the `jaap-karo-release-aab` artifact.

## Signing
Before uploading to Google Play, configure a persistent upload keystore and the Android Gradle `signingConfig` for `release`. The same upload key must be retained for future app updates. The current workflow intentionally does not generate or store a signing key automatically.
